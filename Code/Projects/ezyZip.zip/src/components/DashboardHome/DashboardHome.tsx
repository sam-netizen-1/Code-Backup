import Header from "../Header/Header";
import Select from "../Select/Select";
import Tabel from "../Tabel/Tabel";
import styles from "./DashboardHome.module.scss";
import { IDashboardHomeProps } from "./DashboardHome.types";
import server from "../../Services/https";
import { useEffect, useReducer } from "react";
import {
    dashboardFilterReducer,
    dashboardHomeReducer,
    dashboardPaginateReducer,
} from "./DashboardHome.reducer";
import { ITableActions } from "../Tabel/Tabel.types";
import SerchableDropdown from "../SerchableDropdown/SerchableDropdown";
import TableFilter from "../TableFilter/TableFilter";

const DashboardHome = () => {
    const [data, dataDispatch] = useReducer(dashboardHomeReducer, "");
    async function getdata() {
        const res = await server.getDashBoardData();
        console.log(res);
        dataDispatch({ payload: res.data });
    }
    const [filter, filterDispatch] = useReducer(dashboardFilterReducer, "");
    const [paginate, paginateDispatch] = useReducer(dashboardPaginateReducer, {
        pageNo: 1,
        pageCount: 25,
    });

    const pagination = (data: any) => {
        paginateDispatch(data);
    };
    const columns = [
        "customerName",
        "pONumber",
        "pODate",
        // "makeAt",
        "status",
        "total",
        "grandTotal",
        "amountPaid",
        // "storedAt",
        // "storedAt",
    ];

    useEffect(() => {
        getdata();
        console.log(paginate);
    }, [paginate]);

    const headerLogic = (
        <div className={styles.header}>
            {/* <Select
                type={"select"}
                label={"State"}
                name={""}
                options={[
                    { label: "All", value: "All" },
                    { label: "Production", value: "Production" },
                    { label: "Pending", value: "Pending" },
                    { label: "Storage", value: "Storage" },
                    { label: "Shipped", value: "Shipped" },
                ]}
                onChange={(e) => console.log(e)}
                value={"All"}
            />*/}
            {/* <SerchableDropdown /> */}
            <TableFilter />
        </div>
    );

    return (
        <div className={styles["dashboard-home"]}>
            <Header title="Home" JSX={headerLogic} />
            {/* <Select label=""/> */}
            <div className={styles["table-container"]}>
                <Tabel
                    columns={columns}
                    data={data}
                    // actions={actions}
                    pagination={pagination}
                />
            </div>
        </div>
    );
};
export default DashboardHome;
