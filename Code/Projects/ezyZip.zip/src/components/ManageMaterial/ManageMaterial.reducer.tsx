import FormComponent from "../FormComponent/FormComponent/FormComponent";
import { InputType } from "../FormComponent/FormComponent/FormComponent.types";

const formData: InputType[] = [
    {
        type: "text",
        required: true,
        name: "materialName",
        label: "Material Name",
        placeholder: "ex : Aluminiun",
    },

    {
        type: "number",
        label: "Price per Kg",
        name: "pricePerKg",
        required: true,
        placeholder: "100",
        attribute: { min: 1 },
    },
    {
        type: "text",
        label: "Description",
        name: "description",
        required: true,
        placeholder: "ex : Strong material",
    },
];

const generateEditFormField = (data: any): any => {
    const form: any = [];
    for (let element of formData) {
        const temp: any = { ...element };
        temp.defaultValue = data[temp.name];
        form.push(temp);
    }
    console.log(form);
    return form;
};

export const manageMaterialReducer = (state: any, action: any) => {
    console.log(action.payload);
    if (action.type === "addMaterial") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => action.payload(e)}
                    formFields={formData}
                />
            ),
        };
    } else if (action.type === "editMaterial") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({ _id: action.payload["_id"], ...e });
                    }}
                    formFields={generateEditFormField(action.payload)}
                />
            ),
        };
    } else if (action.type === "deleteMaterial") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({
                            materialId: action.payload["_id"],
                            ...e,
                        });
                    }}
                    formFields={[
                        {
                            type: "button",
                            label: "Are you sure ?",
                            name: "delete",
                            onClick: () => {},
                            attribute: { disabled: true },
                        },
                    ]}
                />
            ),
        };
    } else if (action.type === "updateTabel") {
        console.log(action.payload);
        if (action.payload.data) {
            return { ...state, data: action.payload };
        } else {
            return { ...state, data: null };
        }
    }
    return { ...state, open: action.open };
};
