import Header from "../Header/Header";
import styles from "./OrderDetails.module.scss";
import { IOrderDetailsProps } from "./OrderDetails.types";

const OrderDetails = () => {
    return (
        <div className={styles.container}>
            <Header title={"View Order Details"} />
            <div className={styles.section}>
                <div></div>
            </div>
        </div>
    );
};
export default OrderDetails;
