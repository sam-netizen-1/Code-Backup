export const paymentReducer = (state: any, action: any) => {
    if (action.type === "setData") {
        return action.payload;
    }
};
