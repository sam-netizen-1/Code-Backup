import { useEffect, useReducer, useState } from "react";
import Header from "../Header/Header";
import SerchableDropdown from "../SerchableDropdown/SerchableDropdown";
import styles from "./ManageOrder.module.scss";
import { manageOrderReducer } from "./ManageOrder.reducer";
import { IManageOrderProps } from "./ManageOrder.types";
import server from "../../Services/https";
import ManageOrderItemComponent from "../ManageOrderItemComponent/ManageOrderItemComponent";

const str: any = "";

const ManageOrder = () => {
    const [orderData, orderDataDispatch] = useReducer(manageOrderReducer, {
        orderNumberList: [],
    });

    console.log(orderData);
    const getOrdersNumbers = async () => {
        try {
            const res: any = await server.getOrdersNumber();
            orderDataDispatch({
                type: "updateOrderNumberList",
                payload: res?.data,
            });
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        getOrdersNumbers();
    }, []);
    const getOrderDetails = () => {};

    const jsx = (
        <form className={styles["header-jsx"]} onSubmit={() => {}}>
            <div>Search Order No </div>{" "}
            <SerchableDropdown
                name={"order-no"}
                itemsList={orderData.orderNumberList}
            />
            <button>Get Details</button>
        </form>
    );
    return (
        <div className={styles.container}>
            <Header title={"Add Order"} JSX={jsx} />
            <section className={styles.section}>
                <div className={styles["sub-section"]}>
                    <ManageOrderItemComponent />
                    <ManageOrderItemComponent />
                    <ManageOrderItemComponent />
                    <ManageOrderItemComponent />
                    <section className={styles.deliever}>
                        <div className={styles["item-header"]}>
                            <i
                                className={
                                    "fa-solid " +
                                    `${
                                        Boolean(str == "delievered")
                                            ? styles["delieverd"] +
                                              " fa-circle-check"
                                            : styles["not-delieverd"] +
                                              " fa-circle-xmark"
                                    }`
                                }
                            ></i>
                            <div>Delivery Status</div>
                        </div>
                        <form
                            action=""
                            className={styles["upload-delievery-form"]}
                        >
                            <div>
                                <label htmlFor="packing-charges">
                                    Packaging Charges (in Rs)
                                </label>
                                <input
                                    type="number"
                                    min={0}
                                    defaultValue={0}
                                    id="packing-charges"
                                    required
                                />
                            </div>
                            <div>
                                <label htmlFor="shipping-charges">
                                    Shipping Charges (in Rs)
                                </label>
                                <input
                                    type="number"
                                    min={0}
                                    defaultValue={0}
                                    id="shipping-charges"
                                    required
                                />
                            </div>
                            <div>
                                <label htmlFor="upload-slip">
                                    Upload Delievery Slip
                                </label>
                                <input type="file" id="upload-slip" required />
                            </div>
                            <button>Confirm Delivery</button>
                        </form>
                    </section>
                </div>
            </section>
        </div>
    );
};
export default ManageOrder;
