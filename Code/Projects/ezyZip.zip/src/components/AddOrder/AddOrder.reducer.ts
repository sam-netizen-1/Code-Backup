export const addOrderReducer = (state: any, action: any) => {
    const clonedState: any = { ...state };
    if (action.type === "update") {
        return { ...state, ...action?.payload };
    } else if (action.type === "addItem") {
        console.log("addItem");
        clonedState.items = [...action.payload];
        return clonedState;
    } else if (action.type === "removeItem") {
        clonedState.items = [...action.payload];
        return clonedState;
    } else if (action.type === "updateItem") {
        console.log(action.payload.index);
        const { name, index, value } = action.payload;
        clonedState.items[index][name] = value;
        return clonedState;
    } else {
        return clonedState;
    }
};
export const formFieldReducer = (state: any, action: any) => {
    if (action.type == "updateMaterial") {
    }
};
