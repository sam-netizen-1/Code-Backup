import { useEffect, useRef, useState } from "react";
import { useReducer } from "react";
import { changeCase } from "../../Services/utils";
import FormItem from "../FormItem/FormItem";
import Header from "../Header/Header";
import styles from "./AddOrder.module.scss";
import { addOrderReducer } from "./AddOrder.reducer";
import { IAddOrderProps } from "./AddOrder.types";
import server from "../../Services/https";

const item = {
    itemName: "",
    length: "1",
    width: "1",
    height: "1",
    quantity: "10",
    material: "",
};

const object = {
    items: [item],
    customerName: "",
    shippingAddress: "",
    billingAddress: "",
    packingCharges: "",
    freightCharge: "",
};

let optionList = [
    { name: "Please select" },
    { name: "Aluminium" },
    { name: "Copper" },
    { name: "Zinc" },
];

const AddOrder = () => {
    const [order, orderDispatch] = useReducer(addOrderReducer, object);
    const [formFields, formFieldsDispatch] = useReducer(addOrderReducer, {
        optionList: [{ name: "Please select" }],
        hsnList: [{ name: "Please select" }],
    });
    console.log(order);
    const handleSubmit = (e: any) => {
        e.preventDefault();
    };
    const onChange = (e: any) => {
        orderDispatch(e);
    };

    const getDetailesHandler = async () => {
        const material = await server.getMaterial();
        optionList = [
            { name: "Please select" },
            ...material.data.data.map(({ materialName }: any) => ({
                name: materialName,
            })),
        ];
        console.log(optionList);
    };
    useEffect(() => {
        getDetailesHandler();
    });
    const addButtonRef = useRef<any>({});
    useEffect(() => {
        addButtonRef.current.scrollIntoView({
            behavior: "smooth",
        });
    });

    return (
        <div className={styles["add-order-home"]}>
            <Header title={"Add Order"} />
            <form onSubmit={handleSubmit} className={styles["form-container"]}>
                <div className={styles["details-container"]}>
                    <div>
                        <label htmlFor="company-name-input">Company Name</label>
                        <input id="company-name-input" type="text" />
                    </div>
                    <div>
                        <label htmlFor="hsn-input">HSN Number</label>
                        <input id="hsn-input" type="text" />
                    </div>
                    <button>
                        Submit <i className="fa-regular fa-circle-check"></i>
                    </button>
                </div>

                <div className={styles["items-container"]}>
                    {order.items.map((item: any, index: number) => {
                        return (
                            <FormItem
                                data={item}
                                index={index}
                                onChange={onChange}
                                orderItems={order.items}
                                optionList={formFields.optionList}
                            />
                        );
                    })}
                    <button
                        className={styles["add-items-btn"]}
                        type={"button"}
                        ref={addButtonRef}
                        onClick={(e) => {
                            orderDispatch({
                                type: "addItem",
                                payload: [...order.items, { ...item }],
                            });
                        }}
                    >
                        Add Item <i className="fa-solid fa-cart-plus"></i>
                    </button>
                </div>
            </form>
        </div>
    );
};
export default AddOrder;
