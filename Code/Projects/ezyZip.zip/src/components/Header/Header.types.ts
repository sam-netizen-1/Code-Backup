export interface IHeaderProps {
    JSX?: JSX.Element;
    title: string;
}
