export const itemReducer = (state: any, action: any) => {
    if (action.type === "close") {
        return { ...state, open: !state.open };
    } else if (action.type === "updateStorage") {
        return { ...state, ...action.payload, status: "storage" };
    } else if (action.type === "updateProduction") {
        return { ...state, ...action.payload, status: "production" };
    }
};
