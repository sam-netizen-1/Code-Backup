import { useReducer, useState } from "react";
import FormComponent from "../FormComponent/FormComponent/FormComponent";
import Select from "../FormComponent/Select/Select";
import styles from "./ManageOrderItemComponent.module.scss";
import { itemReducer } from "./ManageOrderItemComponent.reducer";
import { IManageOrderItemComponentProps } from "./ManageOrderItemComponent.types";

const ManageOrderItemComponent = () => {
    const [item, setItemDispatcher] = useReducer(itemReducer, {
        open: false,
        status: "pending",
        furnace: "",
        storage: "",
    });

    const getFormData = (element: any) => {
        const formData = new FormData(element.currentTarget).entries();
        const obj: any = {};
        for (let [key, value] of formData) {
            obj[key] = value;
        }
        return obj;
    };

    return (
        <section
            className={
                styles["item-container"] +
                " " +
                `${item.open ? styles["expand"] : ""}` +
                ` ${
                    Boolean(
                        (item.status === "production" ||
                            item.status === "storage") &&
                            item.open
                    )
                        ? styles["expand-full"]
                        : ""
                }`
            }
        >
            <div className={styles["item-header"]}>
                <div onClick={() => setItemDispatcher({ type: "close" })}>
                    <i
                        className={
                            "fa-solid fa-circle-chevron-down  " +
                            styles["item-dropdown"] +
                            " " +
                            `${item.open ? styles["expanded"] : ""}`
                        }
                    ></i>
                </div>
                <div className={styles["item-header-name"]}>Item 1</div>
                <div className={styles["item-header-name"]}>Progress</div>
                <div className={styles["item-header-progress-container"]}>
                    <div className={styles["item-progress-header"]}>
                        <div className={styles["item-progress-indicator"]}>
                            <div
                                className={
                                    styles["pending"] +
                                    " " +
                                    `${
                                        item.status === "production"
                                            ? styles["production"]
                                            : ""
                                    }` +
                                    `${
                                        item.status === "storage"
                                            ? styles["storage"]
                                            : ""
                                    }`
                                }
                            ></div>
                        </div>
                        <div
                            className={
                                styles["progress"] + " " + styles["done"]
                            }
                        >
                            <i className={"fa-solid fa-check"}></i>
                        </div>
                        <div
                            className={
                                styles["progress"] +
                                " " +
                                `${
                                    item.status === "production" ||
                                    item.status === "storage"
                                        ? styles["done"]
                                        : styles["not-done"]
                                }`
                            }
                        >
                            <i
                                className={
                                    "fa-solid " +
                                    `${
                                        item.status === "production" ||
                                        item.status === "storage"
                                            ? "fa-check"
                                            : "fa-xmark"
                                    }`
                                }
                            ></i>
                        </div>
                        <div
                            className={
                                styles["progress"] +
                                " " +
                                `${
                                    item.status === "storage"
                                        ? styles["done"]
                                        : styles["not-done"]
                                }`
                            }
                        >
                            <i
                                className={
                                    "fa-solid " +
                                    `${
                                        item.status == "storage"
                                            ? "fa-check"
                                            : "fa-xmark"
                                    }`
                                }
                            ></i>
                        </div>
                    </div>
                    <div className={styles["item-progress-header-lable"]}>
                        <span>Pending</span>
                        <span>Production</span>
                        <span>Storage</span>
                    </div>
                </div>
            </div>
            {item.open && (
                <section
                    className={
                        styles["items-details"] +
                        ` ${
                            item.status === "pending"
                                ? ""
                                : styles["disable-form"]
                        }`
                    }
                >
                    <div>
                        <h3>
                            <i
                                className={`${
                                    item.status == "pending"
                                        ? "fa-solid fa-circle-xmark " +
                                          styles["xmark"]
                                        : "fa-solid fa-circle-check " +
                                          styles["check"]
                                }`}
                            ></i>
                            Send To Production
                        </h3>
                        <form
                            action=""
                            onSubmit={(e) => {
                                e.preventDefault();
                                console.log(e);
                                setItemDispatcher({
                                    type: "updateProduction",
                                    payload: getFormData(e),
                                });
                            }}
                        >
                            <Select
                                disabled={Boolean()}
                                required
                                type={"select"}
                                label={"Assing Furnace"}
                                name={"furnace"}
                                defaultValue={"3"}
                                options={[
                                    { label: "Select a Furnace", value: "" },
                                    { label: "Furnace 1", value: "1" },
                                    { label: "Furnace 2", value: "2" },
                                    { label: "Furnace 3", value: "3" },
                                ]}
                            />
                            <div className={styles["submit-btn-container"]}>
                                <label htmlFor="">Send To Production : </label>
                                <button>Confirm</button>
                            </div>
                        </form>
                    </div>
                </section>
            )}
            {Boolean(
                (item.status === "production" || item.status === "storage") &&
                    item.open
            ) && (
                <section
                    className={
                        styles["items-details"] +
                        ` ${
                            item.status === "storage"
                                ? styles["disable-form"]
                                : ""
                        }`
                    }
                >
                    <div>
                        <h3>
                            <i
                                className={`${
                                    item.status == "storage"
                                        ? "fa-solid fa-circle-check  " +
                                          styles["check"]
                                        : "fa-solid fa-circle-xmark " +
                                          styles["xmark"]
                                }`}
                            ></i>
                            Send To Storage
                        </h3>
                        <form
                            action=""
                            onSubmit={(e) => {
                                e.preventDefault();
                                console.log(e);
                                setItemDispatcher({
                                    type: "updateStorage",
                                    payload: getFormData(e),
                                });
                            }}
                        >
                            <Select
                                disabled={Boolean()}
                                required
                                type={"select"}
                                label={"Assing Storage"}
                                name={"storage"}
                                defaultValue={"3"}
                                options={[
                                    { label: "Select a Storage", value: "" },
                                    { label: "Storage 1", value: "1" },
                                    { label: "Storage 2", value: "2" },
                                    { label: "Storage 3", value: "3" },
                                ]}
                            />
                            <div className={styles["submit-btn-container"]}>
                                <label htmlFor="">Send To Storage : </label>
                                <button>Confirm</button>
                            </div>
                        </form>
                    </div>
                </section>
            )}
        </section>
    );
};
export default ManageOrderItemComponent;
