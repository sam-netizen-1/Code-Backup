import { useEffect, useReducer } from "react";
import Header from "../Header/Header";
import PopUp from "../PopUp/PopUp";
import Tabel from "../Tabel/Tabel";
import styles from "./ManageCustomer.module.scss";
import { manageCustomerReducer } from "./ManageCustomer.reducer";
import { IManageCustomerProps } from "./ManageCustomer.types";
import server from "../../Services/https";
import { ITableActions } from "../Tabel/Tabel.types";

const columns = [
    "clientName",
    "clientState",
    "shippingAddress",
    "billingAddress",
];

const ManageCustomer = () => {
    const [customer, setCustomer] = useReducer(manageCustomerReducer, {
        type: "",
        open: false,
        payload: {},
        data: {},
    });

    // console.log(customer.data.data);

    const addCustomerHandler = async (data: any) => {
        const res = await server.addCustomer(data);
        console.log(res);
        if (res.data.data) {
            setCustomer({
                open: false,
                payload: {},
            });
            getCustomerHandler();
        }
    };

    const getCustomerHandler = async () => {
        try {
            const res = await server.getCustomer();
            console.log(res);
            setCustomer({ type: "updateTabel", payload: res.data });
        } catch (error) {
            console.log(error);
        }
    };

    const editCustomerHandler = async (data: any) => {
        console.log(data);
        try {
            const res = await server.editCustomer(data);
            console.log(res);
            if (res.data.data) {
                getCustomerHandler();
                setCustomer({
                    open: false,
                    payload: {},
                });
            }
        } catch (error) {
            console.log(error);
        }
    };
    const deleteCustomerHandler = async (data: any) => {
        console.log(data);
        if (data) {
            try {
                const res = await server.deleteCustomer(data);
                console.log(res);
                if (res.data.data) {
                    getCustomerHandler();
                    setCustomer({
                        open: false,
                        payload: {},
                    });
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            getCustomerHandler();
            setCustomer({
                open: false,
                payload: {},
            });
        }
    };
    const actions: ITableActions = {
        edit: (index: any) => {
            setCustomer({
                open: true,
                type: "editUser",
                payload: customer.data.data[index],
                handler: editCustomerHandler,
            });
            console.log(customer.data.data[index]);
        },
        delete: (index: any) => {
            setCustomer({
                open: true,
                type: "deleteUser",
                payload: customer.data.data[index],
                handler: deleteCustomerHandler,
            });
            console.log(customer.data.data[index]);
        },
    };

    useEffect(() => {
        getCustomerHandler();
    }, []);
    const addCustomer = (
        <>
            <button
                className={styles["add-btn"]}
                onClick={() => {
                    setCustomer({
                        type: "addCustomer",
                        open: true,
                        payload: addCustomerHandler,
                    });
                }}
            >
                Add Customer
            </button>
        </>
    );
    return (
        <>
            <div className={styles["container"]}>
                {customer.open && (
                    <PopUp
                        closeHandler={() => {
                            setCustomer({
                                open: false,
                                payload: {},
                            });
                        }}
                        JSX={customer.payload}
                    />
                )}
                <Header title={"Manage Customers"} JSX={addCustomer} />
                <div className={styles["tabel-container"]}>
                    {Boolean(customer.data.data) && (
                        <Tabel
                            columns={columns}
                            data={customer.data}
                            actions={actions}
                        />
                    )}
                </div>
            </div>
        </>
    );
};
export default ManageCustomer;
