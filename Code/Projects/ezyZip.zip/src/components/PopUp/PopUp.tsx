import FormComponent from "../FormComponent/FormComponent/FormComponent";
import styles from "./PopUp.module.scss";
import { IPopUpProps } from "./PopUp.types";

const PopUp = ({ JSX, closeHandler }: IPopUpProps) => {
    return (
        <section className={styles["popup-container"]}>
            {JSX}
            <div
                className={styles["popup-container-bg"]}
                onClick={(e) => {
                    e.stopPropagation();
                    closeHandler();
                }}
            ></div>
        </section>
    );
};
export default PopUp;
