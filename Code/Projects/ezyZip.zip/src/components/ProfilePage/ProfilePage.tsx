import { useContext } from "react";
import FormComponent from "../FormComponent/FormComponent/FormComponent";
import Header from "../Header/Header";
import { LayoutContext } from "../Layout/Layout";
import styles from "./ProfilePage.module.scss";
import { IProfilePageProps } from "./ProfilePage.types";
import server from "../../Services/https";

const formField = [
    {
        type: "text",
        label: "Old Password",
        name: "oldPassword",
    },
    {
        type: "text",
        label: "New Password",
        name: "newPassword",
    },
    {
        type: "password",
        label: "Confirm Password",
        name: "newPassword2",
    },
];
const ProfilePage = () => {
    const context = useContext(LayoutContext);
    console.log(context);
    const submitHandler = async (e: any) => {
        const obj = { ...e, email: context.PageData.email };
        console.log(obj);
        try {
            const res = await server.resetPassword(obj);
            console.log(res);
        } catch (error) {
            console.log(error);
        }
    };
    return (
        <div>
            <Header title={"Profile"} />
            <div className={styles.container}>
                <h3>Reset Password</h3>
                <FormComponent
                    formDetail={submitHandler}
                    formFields={formField}
                />
            </div>
        </div>
    );
};
export default ProfilePage;
