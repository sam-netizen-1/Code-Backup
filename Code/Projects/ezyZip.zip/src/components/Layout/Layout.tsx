import { createContext, useReducer } from "react";
import { pageChangeReducer } from "../../Services/reducer";
import { getRoute, pageRoutes, RoutesFactory } from "../../Services/routes";
import SideBar from "../SideBar/SideBar";
import { ISideBarItem, ISideBarProps } from "../SideBar/SideBar.types";
import styles from "./Layout.module.scss";
import { ILayoutProps } from "./Layout.types";

export const LayoutContext = createContext<any>(null);

const Layout = () => {
    const [PageData, setPageData] = useReducer(pageChangeReducer, {
        routes: "Login",
        email: "",
    });
    return (
        <LayoutContext.Provider
            value={{ PageData: PageData, setPageData: setPageData }}
        >
            <div className={styles.layout}>
                {/* <RoutesFactory routesList={pageRoutes} /> */}
                {getRoute(PageData.routes)}
            </div>
        </LayoutContext.Provider>
    );
};
export default Layout;
