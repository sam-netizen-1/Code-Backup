import { useEffect, useReducer } from "react";
import { searchableReducer } from "./SearchableDropdown.reducer";
import styles from "./SerchableDropdown.module.scss";
import { ISerchableDropdownProps } from "./SerchableDropdown.types";

const SerchableDropdown = ({ name, itemsList }: ISerchableDropdownProps) => {
    const [data, dataDispatch] = useReducer(searchableReducer, {
        type: "",
        list: itemsList,
        matched: [],
    });
    useEffect(() => {
        dataDispatch({ ...data, type: "addList", list: itemsList });
    }, [itemsList]);
    console.log(data);
    return (
        <div className={styles["searchable-dropdown-container"]}>
            <input
                name={name}
                type="search"
                onChange={(e) => {
                    dataDispatch({ ...data, type: e.target.value });
                }}
                value={data.type}
            />
            <div className={styles.dropdown}>
                <ul
                    onClick={(e: any) => {
                        const element = e.target.innerHTML;
                        // console.log(element);
                        dataDispatch({ ...data, type: e.target.innerHTML });
                        e.stopPropagation();
                    }}
                >
                    {data.matched.map((element: any) => (
                        <li>{element}</li>
                    ))}
                </ul>
            </div>
        </div>
    );
};
export default SerchableDropdown;
