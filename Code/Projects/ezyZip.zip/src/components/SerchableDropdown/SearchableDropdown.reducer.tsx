export const searchableReducer = (state: any, action: any) => {
    const rgx = RegExp(`${action.type}`, "gi");
    let filteredData = [];
    if (action.type == "addList") {
        return { ...state, type: "", list: action.list };
    }
    if (action.type) {
        filteredData = action.list.filter((element: any) => element.match(rgx));
        if (filteredData[0] === action.type) {
            filteredData = [];
        }
    }
    return { ...state, type: action.type, matched: filteredData };
};
