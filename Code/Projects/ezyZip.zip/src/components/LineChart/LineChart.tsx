import styles from "./LineChart.module.scss";
import { ILineChartProps } from "./LineChart.types";
import CanvasJSReact from "../CanvasJs/canvasjs.react";

const LineChart = ({ data }: any) => {
    let CanvasJSChart = CanvasJSReact.CanvasJSChart;
    return (
        <div>
            <CanvasJSChart options={data} />
        </div>
    );
};
export default LineChart;
