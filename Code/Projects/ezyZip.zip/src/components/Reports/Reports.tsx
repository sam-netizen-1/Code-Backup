import { useEffect, useReducer } from "react";
import BarChart from "../BarChart/BarChart";
import Header from "../Header/Header";
import LineChart from "../LineChart/LineChart";
import PieChart from "../PieChart/PieChart";
import {
    filterReducer,
    reportChangeReducer,
    reportTabs,
} from "./Report.reducer";
import styles from "./Reports.module.scss";
import { IReportsProps } from "./Reports.types";
import server from "../../Services/https";

const ReportsSection = () => {
    const [filterData, filterDispatch] = useReducer(filterReducer, {
        type: "barChart",
        start: 2021,
        end: 2022,
        companyNameList: [],
        companyName: "All",
    });
    const [reportScreen, seteportScreen] = useReducer(reportChangeReducer, {
        type: "barChart",
        chart: <></>,
    });
    const getChartData = async (data: any) => {
        try {
            const res = await server.getReports(data);
            console.log(res);
            seteportScreen({ type: data.type, payload: res.data });
        } catch (error) {
            console.log(error);
        }
    };

    const getCompanyDetails = async () => {
        try {
            const res = await server.getCompanyDetails();
            filterDispatch({
                type: "barChart",
                start: 2021,
                end: 2022,
                companyNameList: res,
                companyName: "All",
            });
        } catch (error) {
            console.log(error);
        }
    };
    useEffect(() => {
        getCompanyDetails();
    }, []);

    useEffect(() => {
        console.log(filterData);
        getChartData(filterData);
    }, [filterData]);

    console.log("Yo");
    return (
        <div className={styles["reports"]}>
            <Header title="Reports" />
            <div className={styles["sub-menu"]}>
                <div className={styles["report-type-switch"]}>
                    <i
                        className="fa-solid fa-chart-simple"
                        onClick={() =>
                            filterDispatch({ ...filterData, type: "barChart" })
                        }
                    >
                        <span className={styles["span"]}>Revenu Report</span>
                    </i>
                    <i
                        className="fa-solid fa-chart-line"
                        onClick={() =>
                            filterDispatch({ ...filterData, type: "lineChart" })
                        }
                    >
                        <span className={styles["span"]}>Sales Report</span>
                    </i>
                    <i
                        className="fa-solid fa-chart-pie"
                        onClick={() =>
                            filterDispatch({
                                ...filterData,
                                companyName: "All",
                                type: "pieChart",
                                basedOn: "Quantity",
                            })
                        }
                    >
                        <span className={styles["span"]}>
                            Customer Orders Report
                        </span>
                    </i>
                </div>
                <div className={styles["report-filters"]}>
                    <div>
                        <label htmlFor="report-start-year">Start Year</label>
                        <input
                            id="report-start-year"
                            type="number"
                            value={filterData.start}
                            onChange={(e) =>
                                filterDispatch({
                                    ...filterData,
                                    start: e.target.value,
                                })
                            }
                            max={+filterData.end - 1}
                        />
                    </div>
                    <div>
                        <label htmlFor="report-end-year">End Year</label>
                        <input
                            id="report-end-year"
                            type="number"
                            value={filterData.end}
                            onChange={(e) =>
                                filterDispatch({
                                    ...filterData,
                                    end: e.target.value,
                                })
                            }
                            min={+filterData.start + 1}
                        />
                    </div>
                    {filterData.type != "pieChart" ? (
                        <div>
                            <label htmlFor="company-name">Company</label>
                            <select
                                name=""
                                id="company-name"
                                value={filterData.companyName}
                                onChange={(e) =>
                                    filterDispatch({
                                        ...filterData,
                                        companyName: e.target.value,
                                    })
                                }
                            >
                                <option value="All">All</option>
                                {filterData.companyNameList.map(
                                    (company: any) => (
                                        <option value={company}>
                                            {company}
                                        </option>
                                    )
                                )}
                            </select>
                        </div>
                    ) : (
                        <div>
                            <label htmlFor="">Based On</label>
                            <select
                                onChange={(e) =>
                                    filterDispatch({
                                        ...filterData,
                                        basedOn: e.target.value,
                                    })
                                }
                                value={filterData.basedOn}
                            >
                                <option value="Price">Price</option>
                                <option value="Quantity">Quantity</option>
                            </select>
                        </div>
                    )}
                </div>
            </div>
            <section className={styles["chart-container"]}>
                {reportScreen.chart}
            </section>
        </div>
    );
};
export default ReportsSection;
