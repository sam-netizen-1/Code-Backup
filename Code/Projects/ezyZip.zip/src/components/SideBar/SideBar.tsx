import { useNavigate } from "react-router-dom";
import styles from "./SideBar.module.scss";
import { ISideBarProps } from "./SideBar.types";

const SideBar = ({ SideBarItems, navigator }: ISideBarProps) => {
    return (
        <section className={styles["side-bar"]}>
            <ul>
                {SideBarItems.map((item) => (
                    <li>
                        <i
                            className={item.icon}
                            onClick={() => navigator(item.navigateTo)}
                            // onClick={() => {
                            //     navigate("../login", { replace: true });
                            // }}
                        >
                            <span className={styles["span"]}>{item.label}</span>
                        </i>
                    </li>
                ))}
            </ul>
        </section>
    );
};
export default SideBar;
