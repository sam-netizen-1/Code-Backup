import { FormEvent, useState } from "react";
import { JsxElement } from "typescript";
import Button from "../Button/Button";
import CheckBox from "../CheckBox/CheckBox";
import Input from "../Input/Input";
import RadioBtns from "../RadioBtns/RadioBtns";
import Select from "../Select/Select";
import styles from "./FormComponent.module.scss";
import { IFormComponentProps } from "./FormComponent.types";

const FormComponent = ({
    formDetail,
    formFields,
    reset,
}: IFormComponentProps) => {
    const [resetForm, setResetForm] = useState(false);
    function resetFields() {
        setResetForm(!resetForm);
    }
    function handelSubmit(e: FormEvent) {
        e.preventDefault();
        const form: any = e.currentTarget;
        const formData = new FormData(form).entries();
        const dataObject: { [key: string]: any } = {};
        const filteredData = formFields
            .filter((field) =>
                ["select", "radio", "checkbox"].includes(field.type)
            )
            .map((element) => element.name);

        filteredData.forEach((field) => (dataObject[field] = ""));

        let isDone: boolean | undefined = false;

        while (!isDone) {
            const { done, value } = formData.next();
            if (!done) {
                dataObject[value[0]] = value[1];
            }
            isDone = done;
        }
        formDetail(dataObject);
        if (reset) {
            resetFields();
        }
    }
    const InputField: { [key: string]: ({}: any) => JSX.Element } = {
        button: Button,
        checkbox: CheckBox,
        select: Select,
        radio: RadioBtns,
    };
    return (
        <form onSubmit={handelSubmit} className={styles.form}>
            {formFields.map((e: any, index: number) => {
                if (InputField[e.type]) {
                    const Field: any = InputField[e.type];

                    return (
                        <Field key={e.type + index} {...e} reset={resetForm} />
                    );
                } else {
                    return (
                        <Input key={e.type + index} {...e} reset={resetForm} />
                    );
                }
            })}

            <button>Submit</button>
        </form>
    );
};
export default FormComponent;
