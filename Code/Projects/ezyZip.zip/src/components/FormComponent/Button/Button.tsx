import styles from "./Button.module.scss";
import { IButtonProps } from "./Button.types";

const Button = ({ name, label, onClick }: IButtonProps) => {
    return (
        <div className={styles.checkbox}>
            <button type="button" id={name + label} onClick={onClick}>
                {label}
            </button>
        </div>
    );
};
export default Button;
