export interface IButtonProps {
    type: "button";
    label: string;
    name: string;
    onClick: () => void;
}
