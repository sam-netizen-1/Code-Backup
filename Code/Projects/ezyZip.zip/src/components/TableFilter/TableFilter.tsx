import { useState } from "react";
import styles from "./TableFilter.module.scss";
import { ITableFilterProps } from "./TableFilter.types";

const TableFilter = () => {
    const [filterSection, filterSectionDispatch] = useState(false);
    return (
        <div className={styles.container}>
            <div onClick={() => filterSectionDispatch(!filterSection)}>
                Filter{"  "}
                <i
                    className={`fa-solid fa-sliders ${
                        filterSection ? styles.active : ""
                    }`}
                ></i>
            </div>
            {filterSection && (
                <div className={styles["container-fields"]}>
                    <div className={styles["status-checkbox"]}>
                        <div>Status</div>
                        <div className={styles["checkbox-grid"]}>
                            <div>
                                <input type="checkbox" id="status-pending" />
                                <label htmlFor="status-pending">Pending</label>
                            </div>
                            <div>
                                <input type="checkbox" id="status-pending" />
                                <label htmlFor="status-pending">
                                    Production
                                </label>
                            </div>
                            <div>
                                <input type="checkbox" id="status-pending" />
                                <label htmlFor="status-pending">Storage</label>
                            </div>
                            <div>
                                <input type="checkbox" id="status-pending" />
                                <label htmlFor="status-pending">
                                    Delievred
                                </label>
                            </div>
                            <div>
                                <input type="checkbox" id="status-pending" />
                                <label htmlFor="status-pending">
                                    Completed
                                </label>
                            </div>
                        </div>
                        <label htmlFor="">PO Number</label>
                        <input type="text" />
                        <label htmlFor="">PO Date</label>
                        <input type="date" />
                        <label htmlFor="">Quantity</label>
                        <div className={styles["checkbox-grid"]}>
                            <input type="number" />
                            <div>
                                <i className="fa-solid fa-arrow-up-9-1"></i>
                                <span>More</span>
                            </div>
                            <div>
                                <i className="fa-solid fa-arrow-down-9-1"></i>
                                <span>Less</span>
                            </div>
                        </div>
                        <label htmlFor="">Customer Name</label>
                        <input type="text" />
                    </div>
                    <div className={styles["action-btn-container"]}>
                        <div>Clear All Filter</div>
                        <div className={styles["action-btns-holder"]}>
                            <div>Cancel</div>
                            <div>Apply</div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
export default TableFilter;
