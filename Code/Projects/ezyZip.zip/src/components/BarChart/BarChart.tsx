import CanvasJSReact from "../CanvasJs/canvasjs.react";
import styles from "./BarChart.module.scss";
import { IBarChartProps } from "./BarChart.types";

const Chart = ({ data }: { data: any }) => {
    let CanvasJSChart = CanvasJSReact.CanvasJSChart;

    return (
        <div>
            <CanvasJSChart options={data} />
        </div>
    );
};
export default Chart;
