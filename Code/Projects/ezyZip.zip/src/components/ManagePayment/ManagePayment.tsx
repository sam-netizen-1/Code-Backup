import Header from "../Header/Header";
import SerchableDropdown from "../SerchableDropdown/SerchableDropdown";
import styles from "./ManagePayment.module.scss";
import { IManagePaymentProps } from "./ManagePayment.types";
import server from "../../Services/https";
import { useEffect, useReducer } from "react";
import { manageOrderNumberReducer } from "./ManagePaymentReducer";

const ManagePayment = () => {
    const [orderNumberList, setOrderNumberList] = useReducer(
        manageOrderNumberReducer,
        []
    );
    const getCompanyName = async () => {
        try {
            const res: string[] = await server.getCompanyDetails();
            setOrderNumberList({ payload: res });
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        getCompanyName();
    }, []);

    const searchBar = (
        <form className={styles.searchbar}>
            <div>Search Order </div>
            <SerchableDropdown name={"orderNo"} itemsList={orderNumberList} />
            <button>Get Order Details</button>
        </form>
    );
    return (
        <div className={styles["manage-payment"]}>
            <Header title={"Manage Payment"} JSX={searchBar} />
            <section className={styles.section}>
                <div className={styles["payment-section"]}>
                    <h3> Make Payment </h3>
                    <div className={styles["order-details"]}>
                        <h4 className={styles["order-number"]}>Order No :</h4>
                        <div>{"asdfghjkl"}</div>
                        <h4 className={styles["order-number"]}>
                            Total Payment :
                        </h4>
                        <div>{"asdfghjkl"}</div>
                        <h4 className={styles["order-number"]}>
                            Payment Done :
                        </h4>
                        <div>{"asdfghjkl"}</div>
                        <h4 className={styles["order-number"]}>
                            Outstanding Payment :
                        </h4>
                        <div>{"asdfghjkl"}</div>
                        <label
                            htmlFor={"make-payment-amount"}
                            className={styles["order-number"]}
                        >
                            Enter Amount :
                        </label>
                        <input id={"make-payment-amount"} type="number" />
                        <button className={styles["add-payment-section"]}>
                            Make Payment
                        </button>
                    </div>
                </div>
                <div className={styles.divider}>
                    <div></div>
                </div>
                <div className={styles["payment-history"]}>
                    <h3>Payment History</h3>
                    <ul>
                        {"29-06-2000:"
                            .repeat(20)
                            .split(":")
                            .map((element) => (
                                <li>
                                    Date : {element} Payment : {"10000"} Rs
                                </li>
                            ))}
                    </ul>
                </div>
            </section>
        </div>
    );
};
export default ManagePayment;
