const years = (start, end) => {
    const year = [];
    for (let i = start; i <= end; i++) {
        for (let j = 1; j <= 12; j++) {
            year.push(`${i}-${j}-01`);
        }
    }
    return year;
};

export const companyName = [
    "EXOPLODE",
    "GAZAK",
    "IMANT",
    "VERBUS",
    "COMTRAIL",
    "EMTRAC",
    "ENQUILITY",
    "GOLOGY",
    "ZOSIS",
    "KINDALOO",
    "BOILICON",
    "COMVEYOR",
];
const year = years(2010, 2022);
const db = [];

for (let i = 0; i < 500; i++) {
    const obj = {};
    const name = companyName[Math.floor(Math.random() * companyName.length)];
    const years = year[Math.floor(Math.random() * year.length)];
    obj.companyName = name;
    obj.year = years;
    obj.turnOver = 1000 * Math.floor(Math.random() * 50);
    obj.quantity = 100 * Math.floor(Math.random() * 15);
    db.push(obj);
}
db.sort((a, b) => new Date(a.year) - new Date(b.year));
console.table(db[0].year);
console.log(new Date(`2021`));
const chart = {
    barChart: {
        animationEnabled: true,
        zoomEnabled: true,
        exportEnabled: true,
        theme: "light2", // "light1", "dark1", "dark2"
        title: {
            text: "Revenue Rate by Month of Year",
        },
        axisY: {
            title: "Revenue Rate",
            suffix: "Rs",
        },
        axisX: {
            title: "Month of Year",
            interval: 1,
            intervalType: "month",
            valueFormatString: "YYYY MMM",
            gridThickness: 1,
        },
        data: [
            {
                type: "column",
                toolTipContent: "Week {x}: {y}%",
                xValueFormatString: "MMM, YYYY",
                dataPoints: [],
            },
        ],
    },
    pieChart: {
        exportEnabled: true,
        animationEnabled: true,
        title: {
            text: "Website Traffic Sources",
        },
        data: [
            {
                type: "pie",
                startAngle: 75,
                toolTipContent: "<b>{label}</b>: {y} %",
                showInLegend: "true",
                legendText: "{label}",
                indexLabelFontSize: 16,
                indexLabel: "{label} - {y} %",
                dataPoints: [
                    { y: 8, label: "Direct" },
                    { y: 49, label: "Organic Search" },
                    { y: 9, label: "Paid Search" },
                    { y: 5, label: "Referral" },
                    { y: 19, label: "Social" },
                ],
            },
        ],
    },
    lineChart: {
        animationEnabled: true,
        zoomEnabled: true,
        exportEnabled: true,
        theme: "light2", // "light1", "dark1", "dark2"
        title: {
            text: "Revenue Rate by Month of Year",
        },
        axisY: {
            title: "Revenue Rate",
            suffix: "Rs",
        },
        axisX: {
            title: "Month of Year",
            interval: 1,
            intervalType: "month",
            valueFormatString: "YYYY MMM",
            gridThickness: 1,
        },
        data: [
            {
                type: "line",
                toolTipContent: "Week {x}: {y}%",
                xValueFormatString: "MMM, YYYY",
                dataPoints: [],
            },
        ],
    },
};
export const filterData = (obj) => {
    let array = [];
    if (obj.companyName != "All") {
        array = db.filter((e) => e.companyName == obj.companyName);
    } else {
        array = db;
    }
    array = array.filter(
        (element) => new Date(element.year) >= new Date(obj.start + "")
    );
    array = array.filter(
        (element) => new Date(element.year) <= new Date(obj.end + "")
    );

    const data = {};
    if (obj.type != "pieChart") {
        array.forEach((a) => {
            if (data[a.year]) {
                data[a.year] += a.turnOver;
            } else {
                data[a.year] = a.turnOver;
            }
        });
        const returnData = Object.entries(data).map((a) => ({
            x: new Date(a[0]),
            y: a[1],
            // markerColor: "#6B8E23",
        }));
        console.table(obj);
        chart[obj.type].data[0].dataPoints = returnData;
    } else {
        array.forEach((e) => {
            const value = obj.basedOn === "Quantity" ? e.quantity : e.turnOver;
            if (data[e.companyName]) {
                data[e.companyName] += value;
            } else {
                data[e.companyName] = value;
            }
        });
        const total = Object.values(data).reduce(
            (sum, value) => sum + value,
            0
        );
        const returnData = Object.entries(data).map((a) => ({
            // y: total / a[1],
            y: a[1],
            label: a[0],
        }));
        chart[obj.type].data[0].dataPoints = returnData;
        chart[obj.type].data[0].toolTipContent = `<b>{label}</b>: {y} ${
            obj.basedOn === "Quantity" ? "Units" : "Cr Rs"
        }`;
        chart[obj.type].data[0].indexLabel = `{label} - {y} ${
            obj.basedOn === "Quantity" ? "Units" : "Cr Rs"
        }`;
    }
    console.log(chart[obj.type]);
    return {
        data: { ...chart[obj.type] },
        start: obj.start,
        end: obj.end,
        companyName: obj.companyName,
    };
};

// const a = filterData({ start: 2012, end: 2021 });
