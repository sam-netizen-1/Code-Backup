const id = [
    "aagSyNegyZMbWXc",
    "WEM9Jtv926HPrzD",
    "35EJbGk7Wpco7ix",
    "7gccwoqYveqBYpS",
    "FDPncVoPe2ej96N",
    "RxDCLKKBJVg2g4G",
    "UMWiippxzE8gPT6",
    "i9K65QdySeZn4P3",
    "HUU2bLXLkX9LaL3",
    "aTwvaAcywsogvYN",
    "vfXZ8YDQyKYin9d",
    "Yy8ttP8ZgtuMNea",
    "YkxYshYa6GRcHAD",
    "LicZyEghYQvBXxH",
    "kkKFQ5siX82swJH",
    "gAzRWXutfqdSzCB",
    "J8fuxJftgcf4nMN",
    "JRxYsbMt5zpcaJ5",
    "ZRt9HWFoSTWw4Ky",
    "rtmuH3b64WDMDeW",
];

const orders = {
    customerName: "Dhoot Transmisssion",
    pONumber: "",
    pODate: "",
    items: {
        itemA: {
            length: "10",
            width: "10",
            height: "10",
            material: "Aluminium",
            quantity: "10",
        },
    },
    makeAt: "Furnace 1",
    shippingAddress: "random place 1234",
    billingAddress: "random place 1234",
    customs: {
        SGST: 5,
        CGST: 5,
        IGST: 2,
    },
    packingCharges: 1000,
    freightCharge: 1000,
    grandTotal: 30000,
    total: 20000,
    amountPaid: 10000,
    outstandingAmount: 20000,
    status: "production",
    paymentHistory: [],
    storedAt: "Building 1 shelf A row 1",
};

const ordersList = [];
for (let i = 0; i < 50; i++) {
    orders.customerName = `random guy ${Math.round(Math.random() * 10)}`;
    orders.pONumber = id[i];
    orders.pODate = new Date();
    orders.paymentHistory.push({
        time: new Date(),
        amount: Math.floor(Math.random() * 1000),
    });
    orders.makeAt = `Furnace ${Math.ceil(Math.random() * 4)}`;

    orders.packingCharges = Math.floor(Math.random() * 1000);
    orders.freightCharge = Math.floor(Math.random() * 1000);
    orders.total = Math.floor(Math.random() * 1000);
    orders.grandTotal =
        orders.packingCharges + orders.freightCharge + orders.total;
    ordersList.push({ ...orders });
    orders.paymentHistory = [];
}

const fs = require("fs");
fs.writeFileSync(
    "./public/Orders.json",
    JSON.stringify({
        data: ordersList,
        next: 1,
        prev: "0",
        currentPage: 2,
        pageSize: "25",
    })
);
