import { useParams } from "react-router-dom";
import styles from "./ForgetPassword.module.scss";
import { IForgetPasswordProps } from "./ForgetPassword.types";
import server from "../../Services/https";

const ForgetPassword = () => {
    let params = useParams();
    console.log(params.token);
    const submitForgetPassword = async (e: any) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget).entries();
        const obj: any = {};
        for (let [key, value] of formData) {
            obj[key] = value;
        }
        if (obj.newPassword2 === obj.newPassword) {
            const res = await server.forgetPassword({
                data: obj,
                token: params.token,
            });
            console.log(res);
        }
    };
    return (
        <form onSubmit={submitForgetPassword}>
            <label htmlFor="">Email</label>
            <input type="text" placeholder="New Password" name="email" />
            <label htmlFor="">New Password</label>
            <input type="text" placeholder="New Password" name="newPassword" />
            <label htmlFor="">Confirm Password</label>
            <input
                type="password"
                placeholder="New Password"
                name="newPassword2"
            />
            <button>Chnage Password</button>
        </form>
    );
};
export default ForgetPassword;
