import { useReducer } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import SideBar from "../../components/SideBar/SideBar";
import { ISideBarItem } from "../../components/SideBar/SideBar.types";
import { screenChangerReducer } from "../../Services/reducer";
import { screenRoutes } from "../../Services/routes";
import styles from "./Accountant.module.scss";
import { IAccountantProps } from "./Accountant.types";

const SideBarItems: ISideBarItem[] = [
    { icon: "fa-solid fa-user", label: "Profile", navigateTo: "profile" },
    { icon: "fa-solid fa-house", label: "Home", navigateTo: "home" },
    {
        icon: "fa-solid fa-cash-register",
        label: "Manage Payment",
        navigateTo: "managePayment",
    },
    {
        icon: "fa-solid fa-clock-rotate-left",
        label: "View History",
        navigateTo: "viewPaymentHistory",
    },
    {
        // icon: "fa-solid fa-info",
        icon: "fa-solid fa-file-invoice",
        label: "Order Details",
        navigateTo: "orderDetails",
    },
    {
        icon: "fa-solid fa-right-from-bracket",
        label: "Logout",
        navigateTo: "logout",
    },
];

const Accountant = () => {
    let navigate = useNavigate();
    const [Screen, screenDispatcher] = useReducer(
        screenChangerReducer,
        screenRoutes.Accountant.home
    );
    const navigateTo = (string: string) => {
        if (string === "logout") {
            navigate("../login", { replace: true });
        } else {
            // screenDispatcher({ type: string, payload: "Accountant" });
            navigate(string);
        }
    };

    return (
        <div className={styles.accountant}>
            <SideBar SideBarItems={SideBarItems} navigator={navigateTo} />
            <div className={styles.screen}>
                {/* <Screen /> */}
                <Outlet />
            </div>
        </div>
    );
};
export default Accountant;
