import { useContext, useReducer } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import DashboardHome from "../../components/DashboardHome/DashboardHome";
import { LayoutContext } from "../../components/Layout/Layout";
import SideBar from "../../components/SideBar/SideBar";
import { ISideBarItem } from "../../components/SideBar/SideBar.types";
import { screenChangerReducer } from "../../Services/reducer";
import {
    adminScreenRoutes,
    clerkScreenRoutes,
    pageRoutes,
    RoutesFactory,
    screenRoutes,
} from "../../Services/routes";

import styles from "./Clerk.module.scss";
import { IClerkProps } from "./Clerk.types";

const SideBarItems: ISideBarItem[] = [
    { icon: "fa-solid fa-user", label: "Profile", navigateTo: "profile" },
    { icon: "fa-solid fa-house", label: "Home", navigateTo: "home" },
    {
        icon: "fa-solid fa-cart-plus",
        label: "Add Order",
        navigateTo: "addOrder",
    },
    {
        icon: "fa-solid fa-bars-progress",
        label: "Manage Order",
        navigateTo: "manageOrder",
    },
    {
        icon: "fa-solid fa-right-from-bracket",
        label: "Logout",
        navigateTo: "logout",
    },
];

const Clerk = () => {
    let navigate = useNavigate();
    const value: any = useContext(LayoutContext);
    const [Screen, screenDispatcher] = useReducer(
        screenChangerReducer,
        screenRoutes.Clerk.home
    );
    const navigateTo = (string: string) => {
        console.log(string);
        if (string === "logout") {
            navigate("../login", { replace: true });
        } else {
            // screenDispatcher({ type: string, payload: "Clerk" });
            navigate(string);
        }
    };
    return (
        <div className={styles.clerk}>
            <SideBar SideBarItems={SideBarItems} navigator={navigateTo} />
            <div className={styles.screen}>
                {/* <Screen /> */}
                <Outlet />
                {/* <RoutesFactory routesList={clerkScreenRoutes} /> */}
            </div>
        </div>
    );
};
export default Clerk;
