import axios from "axios";
import { companyName, filterData } from "../Mockdata/GenerateChartsData";

let jwtToken = {
    token: "",
};
const getJwt = () => {
    return jwtToken.token;
};
const setJwt = (data: string) => {
    jwtToken = { token: data };
};

// const server = axios.create({ baseURL: "" });
const server = axios.create({ baseURL: "http://192.168.1.106:5000/" });

const getDashBoardData = async () => {
    const res = await server.get("/Orders.json");
    return res.data;
};

const loginHandler = async (data: any) => {
    const res = await server.post("auth/login", data);
    console.log(res.data.data);
    if (res.data.data) {
        setJwt(res.data.data.token);
    }
    return res.data.data;
};

const addCustomer = async (data: any) => {
    const res = await server.post("client/", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const getCustomer = async () => {
    const res = await server.get("client/", {
        headers: { Authorization: getJwt() },
    });
    console.log(res);
    return res;
};
const editCustomer = async (data: any) => {
    const res = await server.put("client/edit-client", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const deleteCustomer = async (data: any) => {
    const res = await server.put("client/remove-client", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};

//  Material section

const addMaterial = async (data: any) => {
    const res = await server.post("material/", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const getMaterial = async () => {
    const res = await server.get("material/", {
        headers: { Authorization: getJwt() },
    });
    console.log(res);
    return res;
};
const editMaterial = async (data: any) => {
    const res = await server.put("material/edit-material", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const deleteMaterial = async (data: any) => {
    const res = await server.put("material/remove-material", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};

//  HSN section

const addHSN = async (data: any) => {
    const res = await server.post("hsn/", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const getHSN = async () => {
    const res = await server.get("hsn/", {
        headers: { Authorization: getJwt() },
    });
    console.log(res);
    return res;
};
const editHSN = async (data: any) => {
    const res = await server.put("hsn/edit-hsn", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const deleteHSN = async (data: any) => {
    const res = await server.put("hsn/remove-hsn", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};

//  HSN section

const addFurnace = async (data: any) => {
    const res = await server.post("furnace/", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const getFurnace = async () => {
    const res = await server.get("furnace/get-all-furnaces", {
        headers: { Authorization: getJwt() },
    });
    console.log(res);
    return res;
};
const editFurnace = async (data: any) => {
    const res = await server.put("furnace/edit-furnace", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
const deleteFurnace = async (data: any) => {
    const res = await server.put("furnace/remove-furnace", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};
// ---->
const addUser = async (data: any) => {
    const res = await server.post("auth/add-user", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};

const forgetPassword = async (data: any) => {
    const res = await server.post(
        "auth/forget-password-link",
        { ...data.data },
        {
            headers: { Authorization: data.token },
        }
    );
    return res;
};
const requestForgetPassword = async (data: any) => {
    const res = await server.post("auth/forget-password", data);
    return res;
};
const resetPassword = async (data: any) => {
    // console.log(first)
    const res = await server.post("auth/reset-password", data, {
        headers: { Authorization: getJwt() },
    });
    return res;
};

const getReports = async (data: any) => {
    // const res = await server.post("/", data);
    // return res;
    // console.log(data);
    // return charts[data.type];
    console.log(data);
    return filterData(data);
};
const getCompanyDetails = async () => {
    // const res = await server.get("/");
    // return res;
    // console.log(data);
    return companyName;
};

const getOrdersNumber = async () => {
    // const res = await server.get("/");
    // return res;
    // console.log(data);
    return { data: companyName };
};

const getHistory = async (orderNumber: any) => {
    return {
        data: {
            orderNumber: "asdfgh",
            paymentHistory: [
                { date: "2022-12-29", amount: "10000" },
                { date: "2022-12-29", amount: "10000" },
                { date: "2022-12-29", amount: "10000" },
                { date: "2022-12-29", amount: "10000" },
                { date: "2022-12-29", amount: "10000" },
            ],
        },
    };
};

export default {
    getHistory,
    getDashBoardData,
    loginHandler,
    getReports,
    getCompanyDetails,
    getOrdersNumber,
    // ---------->
    addCustomer,
    getCustomer,
    editCustomer,
    deleteCustomer,
    // ---------->
    addUser,
    forgetPassword,
    requestForgetPassword,
    resetPassword,
    // ---------->
    addMaterial,
    getMaterial,
    editMaterial,
    deleteMaterial,
    // ---------->
    addHSN,
    getHSN,
    editHSN,
    deleteHSN,
    // ---------->
    addFurnace,
    editFurnace,
    deleteFurnace,
    getFurnace,
};
