export function changeCase(string: string) {
    const small = string.split(/[A-Z]/g);
    small[0] = small[0][0].toUpperCase() + small[0].slice(1);
    if (small.length > 1) {
        const capital = string
            .split(/[a-z]/g)
            .filter((a) => a != "")
            .join("")
            .split("");
        for (let index = 1; index < small.length; index++) {
            small[index] = capital[index - 1] + small[index];
        }
    }
    return small.join(" ");
}
