import { Navigate, Route, Routes } from "react-router-dom";
import AddOrder from "../components/AddOrder/AddOrder";
import DashboardHome from "../components/DashboardHome/DashboardHome";
import ManageCustomer from "../components/ManageCustomer/ManageCustomer";
import ManageFurnace from "../components/ManageFurnace/ManageFurnace";
import ManageHSN from "../components/ManageHSN/ManageHSN";
import ManageMaterial from "../components/ManageMaterial/ManageMaterial";
import ManageOrder from "../components/ManageOrder/ManageOrder";
import ManagePayment from "../components/ManagePayment/ManagePayment";
import ManageUsers from "../components/ManageUsers/ManageUsers";
import OrderDetails from "../components/OrderDetails/OrderDetails";
import ProfilePage from "../components/ProfilePage/ProfilePage";
import ReportsSection from "../components/Reports/Reports";
import Reports from "../components/Reports/Reports";
import ViewPaymentHistory from "../components/ViewPaymentHistory/ViewPaymentHistory";
import Accountant from "../Pages/Accountant/Accountant";
import Admin from "../Pages/Admin/Admin";
import Clerk from "../Pages/Clerk/Clerk";
import ForgetPassword from "../Pages/ForgetPassword/ForgetPassword";
import Login from "../Pages/Login/Login";

export interface IPageRoutes {
    [key: string]: {
        path: string;
        element: React.ReactElement;
        exact?: true;
    };
}

export const pageRoutes: IPageRoutes = {
    Admin: {
        path: "/admin",
        element: <Admin />,
        exact: true,
    },
    Accountant: {
        path: "accountant",
        exact: true,
        element: <Accountant />,
    },
    Clerk: {
        path: "clerk",
        exact: true,
        element: <Clerk />,
    },
    Login: {
        path: "login",
        element: <Login />,
    },
    forgetPassword: {
        path: "ForgetPassword/:token",
        element: <ForgetPassword />,
    },
    Default: {
        path: "/",
        exact: true,
        element: <Login />,
    },
    "*": {
        path: "*",
        exact: true,
        element: <Login />,
    },
};

export const RoutesFactory = ({ routesList }: { routesList: IPageRoutes }) => {
    const pages = Object.keys(routesList);
    return (
        <Routes>
            {pages.map((page) => {
                return <Route {...routesList[page]}></Route>;
            })}
        </Routes>
    );
};
export const adminScreenRoutes: IPageRoutes = {
    Home: { path: "/home", element: <DashboardHome /> },
};
export const clerkScreenRoutes: IPageRoutes = {
    Home: { path: "/clerk/home", element: <DashboardHome /> },
};

export const screenRoutes: {
    [key: string]: { [key: string]: (props: any) => JSX.Element };
} = {
    Admin: {
        profile: ProfilePage,
        home: DashboardHome,
        reports: ReportsSection,
        manageUsers: ManageUsers,
        manageHSN: ManageHSN,
        manageMaterial: ManageMaterial,
        manageCustomers: ManageCustomer,
        manageFurnace: ManageFurnace,
    },
    Clerk: {
        profile: ProfilePage,
        home: DashboardHome,
        addOrder: AddOrder,
        manageOrder: ManageOrder,
    },
    Accountant: {
        profile: ProfilePage,
        home: DashboardHome,
        managePayment: ManagePayment,
        viewPaymentHistory: ViewPaymentHistory,
        orderDetails: OrderDetails,
    },
};

const subNavigate: any = {
    Login: {
        main: <Login />,
        path: "/",
    },
    Admin: {
        main: <Admin />,
        subRoutes: [
            <Route index element={<DashboardHome />} />,
            <Route path="home" element={<DashboardHome />} />,
            <Route path="reports" element={<ReportsSection />} />,
            <Route path="profile" element={<ProfilePage />} />,
            <Route path="manageUsers" element={<ManageUsers />} />,
            <Route path="manageHSN" element={<ManageHSN />} />,
            <Route path="manageMaterial" element={<ManageMaterial />} />,
            <Route path="manageCustomers" element={<ManageCustomer />} />,
            <Route path="manageFurnace" element={<ManageFurnace />} />,
            <Route path="*" element={<DashboardHome />} />,
        ],
    },
    Clerk: {
        main: <Clerk />,
        subRoutes: [
            <Route index element={<DashboardHome />} />,
            <Route path="home" element={<DashboardHome />} />,
            <Route path="*" element={<DashboardHome />} />,
            <Route path="profile" element={<ProfilePage />} />,
            <Route path="addOrder" element={<ManageUsers />} />,
            <Route path="manageOrder" element={<ManageOrder />} />,
        ],
    },
    Accountant: {
        main: <Accountant />,
        subRoutes: [
            <Route index element={<DashboardHome />} />,
            <Route path="home" element={<DashboardHome />} />,
            <Route path="*" element={<DashboardHome />} />,
            <Route path="profile" element={<ProfilePage />} />,
            <Route path="managePayment" element={<ManagePayment />} />,
            <Route
                path="viewPaymentHistory"
                element={<ViewPaymentHistory />}
            />,
            <Route path="orderDetails" element={<OrderDetails />} />,
        ],
    },
};

export const getRoute = (section: string) => {
    const route = subNavigate[section];
    console.log(route);
    if (route.subRoutes) {
        return (
            <Routes>
                <Route path={"/"} element={route.main}>
                    {route.subRoutes}
                </Route>
            </Routes>
        );
    } else {
        return (
            <Routes>
                <Route path={route.path} index element={route.main}></Route>
            </Routes>
        );
    }
};
