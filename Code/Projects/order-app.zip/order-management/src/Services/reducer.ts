import { pageRoutes, screenRoutes } from "./routes";

export const pageChangeReducer = (state: any, action: any): any => {
    if (action.type == "login") {
        console.log(action);
        return { email: action.email, routes: action.routes };
    }
    return action.routes;
};

export const screenChangerReducer = (state: any, action: any): any => {
    if (!screenRoutes[action.payload][action.type]) {
        return screenRoutes[action.payload]["home"];
    }
    return screenRoutes[action.payload][action.type];
};
