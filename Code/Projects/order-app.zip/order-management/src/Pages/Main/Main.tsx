import { createContext, useReducer } from "react";
import { pageChangeReducer } from "../../Services/reducer";
import { getRoute } from "../../Services/routes";

import styles from "./Main.module.scss";

export const MainContext = createContext<any>(null);

const Main = () => {
  const [PageData, setPageData] = useReducer(pageChangeReducer, {
    routes: "Login",
    email: "",
  });
  return (
    <MainContext.Provider
      value={{ PageData: PageData, setPageData: setPageData }}
    >
      <div className={styles.layout}>{getRoute(PageData.routes)}</div>
    </MainContext.Provider>
  );
};
export default Main;
