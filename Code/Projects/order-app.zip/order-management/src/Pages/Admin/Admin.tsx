import { useReducer } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import SideBar from "../../components/SideBar/SideBar";
import { ISideBarItem } from "../../components/SideBar/SideBar.types";
import { screenChangerReducer } from "../../Services/reducer";
import { screenRoutes } from "../../Services/routes";
import styles from "./Admin.module.scss";

const SideBarItems: ISideBarItem[] = [
  { icon: "fa-solid fa-user", label: "Profile", navigateTo: "profile" },
  { icon: "fa-solid fa-house", label: "Home", navigateTo: "home" },
  {
    icon: "fa-solid fa-chart-simple",
    label: "Reports",
    navigateTo: "reports",
  },
  {
    icon: "fa-solid fa-users-rectangle",
    label: "Manage Customers",
    navigateTo: "manageCustomers",
  },
  {
    icon: "fa-solid fa-user-gear",
    label: "Manage User",
    navigateTo: "manageUsers",
  },
  {
    icon: "fa-solid fa-circle-nodes",
    label: "Manage Material",
    navigateTo: "manageMaterial",
  },
  {
    icon: "fa-solid fa-money-bill-1-wave",
    label: "Manage HSN",
    navigateTo: "manageHSN",
  },
  {
    icon: "fa-solid fa-gear",
    label: "Manage Furnace",
    navigateTo: "manageFurnace",
  },
  {
    icon: "fa-solid fa-right-from-bracket",
    label: "Logout",
    navigateTo: "logout",
  },
];

const Admin = () => {
  let navigate = useNavigate();
  const [Screen, screenDispatcher] = useReducer(
    screenChangerReducer,
    screenRoutes.Admin.home
  );
  const navigateTo = (string: string) => {
    if (string === "logout") {
      navigate("../login", { replace: true });
    } else {
      navigate(string);
    }
  };

  return (
    <div className={styles.admin}>
      <SideBar SideBarItems={SideBarItems} navigator={navigateTo} />
      <div className={styles.screen}>
        <Outlet />
      </div>
    </div>
  );
};
export default Admin;
