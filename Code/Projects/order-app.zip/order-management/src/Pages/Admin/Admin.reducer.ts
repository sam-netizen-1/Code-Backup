export const changeAdminScreen = (state: any, action: any) => {
    return;
};
