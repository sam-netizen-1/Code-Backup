import styles from "./Login.module.scss";
import server from "../../Services/https";
import { useNavigate } from "react-router-dom";
import { pageRoutes } from "../../Services/routes";
import Admin from "../Admin/Admin";
import { useContext, useReducer } from "react";
import { loginPageReducer } from "./LoginPassword.reducer";
import PopUp from "../../components/PopUp/PopUp";
import { MainContext } from "../Main/Main";

const roles: { [key: string]: string } = {
  id_admin: "Admin",
  id_clerk: "Clerk",
  id_accountant: "Accountant",
};

const Login = () => {
  const context = useContext(MainContext);

  const [loginData, setLoginData] = useReducer(loginPageReducer, {
    data: { email: "", password: "" },
    popup: false,
    message: "",
  });
  const navigate = useNavigate();

  const handleLogin = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    try {
      const res: any = await server.loginHandler(loginData.data);
      context.setPageData({
        type: "login",
        email: loginData.data.email,
        routes: roles[res.roleId],
      });
      // const role = navigate("" + roles[res.roleId], {
      //     replace: true,
      // });
    } catch (error) {
      setLoginData({
        type: "popup",
        popup: true,
        message: "Invalid Credentials",
      });
    }
  };

  const forgetPasswordHandler = async () => {
    if (loginData.data.email) {
      const res = await server.requestForgetPassword({
        email: loginData.data.email,
      });
      if (res.data.data) {
        setLoginData({
          type: "popup",
          popup: true,
          message: res.data.data.message,
        });
      }
      console.log(res);
    } else {
      setLoginData({
        type: "popup",
        popup: true,
        message: "Email Required",
      });
    }
  };
  const onChangeHandler = (e: any) => {
    const { name, value } = e.currentTarget;
    setLoginData({
      type: "inputChange",
      name: name,
      value: value,
    });
  };
  return (
    <div className={styles["login-page"]}>
      {loginData.popup && (
        <PopUp
          closeHandler={() => {
            setLoginData({
              type: "popup",
              popup: false,
              message: "",
            });
          }}
          JSX={<div className={styles.popup}>{loginData.message}</div>}
        />
      )}
      <form className={styles["login-form"]} onSubmit={handleLogin}>
        <div>
          <label htmlFor="username-input">Username</label>
          <input
            name="email"
            id={"username-input"}
            type="text"
            placeholder="example@email.com"
            value={loginData.data.email}
            onChange={onChangeHandler}
          />
        </div>
        <div>
          <label htmlFor="password-input">Password</label>
          <input
            name="password"
            id={"password-input"}
            type="password"
            placeholder="********"
            value={loginData.data.password}
            onChange={onChangeHandler}
          />
        </div>
        <div className={styles["login-page-action"]}>
          <button>Login</button>
          <div onClick={forgetPasswordHandler}>Forgot Password ?</div>
        </div>
      </form>
    </div>
  );
};
export default Login;
