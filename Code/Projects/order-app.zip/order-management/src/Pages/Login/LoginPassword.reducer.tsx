export const loginPageReducer = (state: any, action: any) => {
    if (action.type === "inputChange") {
        console.log(action);
        const data = { ...state.data, [action.name]: action.value };
        return { ...state, data };
    } else if (action.type === "popup") {
        return {
            ...state,
            message: action.message,
            popup: action.popup,
        };
    }
    return { ...state, popup: action.popup };
};
