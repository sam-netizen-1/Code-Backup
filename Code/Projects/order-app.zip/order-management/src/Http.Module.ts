class HTTP {
  mainUrl = "http://192.168.1.106:3000/";
  userToken = " ";
  async send(url: string, options = {}) {
    try {
      const response = await fetch(`${this.mainUrl}${url}`, options);
      const data = await response.json();
      if (data.data.token) {
        this.userToken = data.data.token;
      }
      if (data.data) {
        return data;
      } else {
        throw data.error.message;
      }
    } catch (errorMsg) {
      return { title: "error", message: errorMsg };
    }
  }

  get(url: string) {
    return this.send(url, {
      method: "GET",
      headers: {
        authorization: this.userToken,
      },
    });
  }

  post(url: string, data: any) {
    return this.send(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorization: this.userToken,
      },
      body: JSON.stringify(data),
    });
  }

  postFile(url: string, data: any) {
    return this.send(url, {
      method: "POST",
      headers: {
        Authorization: this.userToken,
      },
      body: data,
    });
  }

  emptyToken() {
    this.userToken = " ";
  }
}

const http = new HTTP();
export default http;

// curl --location --request POST 'localhost:3000/user/add-csv' \
// --header 'Authorization: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJmaXJzdC11c2VyIiwicm9sZUlkIjoiaWRfYWRtaW4iLCJpYXQiOjE2NjUzNzcwNzF9.gn4zqmxLJ2rs8kWrg_XLeBkZUaz6HYhKdRHs2o_oZL0' \
// --form 'user_csv=@"/C:/Users/Coditas/Downloads/dummyCsv.csv"'
