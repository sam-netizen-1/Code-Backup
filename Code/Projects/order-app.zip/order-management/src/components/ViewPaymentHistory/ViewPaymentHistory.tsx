import { useReducer } from "react";
import Header from "../Header/Header";
import SerchableDropdown from "../SerchableDropdown/SerchableDropdown";
import styles from "./ViewPaymentHistory.module.scss";
import { paymentReducer } from "./ViewPaymentHistory.reducer";
import server from "../../Services/https";

const ViewPaymentHistory = () => {
  const [history, setHistoryDispatch] = useReducer(paymentReducer, {
    orderNumber: "asdfghjk",
    paymentHistory: [{ date: "2022-12-29", amount: "10000" }],
  });

  const getHistory = async (e: any) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget).entries();
    const object: any = [];

    for (let i of formData) {
      object.push(i);
      console.log(i);
    }

    try {
      const res = await server.getHistory(object[0][1]);
      console.log(res.data);
      setHistoryDispatch({ type: "setData", payload: res.data });
    } catch (error) {
      console.log(error);
    }
  };

  const searchSection = (
    <form onSubmit={getHistory} className={styles["header"]}>
      <div>Search Order</div>
      <SerchableDropdown name={"orderNumber"} itemsList={[]} />
      <button>Get Details</button>
    </form>
  );
  return (
    <div className={styles.container}>
      <Header title={"View Payment History"} JSX={searchSection} />
      {Boolean(history.orderNumber) && (
        <div className={styles.section}>
          <h3>Order No : {history.orderNumber}</h3>
          <ul>
            {history.paymentHistory.map(({ date, amount }: any) => (
              <li>
                <div>Payed On : {date}</div>
                <div>Payed Amount : {amount}</div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
export default ViewPaymentHistory;
