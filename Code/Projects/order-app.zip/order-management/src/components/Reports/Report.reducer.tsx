import BarChart from "../BarChart/BarChart";
import Chart from "../BarChart/BarChart";
import CanvasJSReact from "../CanvasJs/canvasjs.react";
import LineChart from "../LineChart/LineChart";
import PieChart from "../PieChart/PieChart";

export const reportTabs = {
    lineChart: LineChart,
    barChart: Chart,
    pieChart: PieChart,
};

export interface IReportTabs {
    lineChart: (props: any) => JSX.Element;
    barChart: (props: any) => JSX.Element;
    pieChart: (props: any) => JSX.Element;
}

export const reportChangeReducer = (
    state: any,

    action: {
        type: "lineChart" | "barChart" | "pieChart";
        start?: number;
        end?: number;
        payload: any;
    }
) => {
    const Chart = reportTabs[action.type];
    return {
        type: action.type,
        chart: <Chart data={action.payload} />,
    };
};

export const filterReducer = (state: any, action: any) => {
    return { ...action };
};
