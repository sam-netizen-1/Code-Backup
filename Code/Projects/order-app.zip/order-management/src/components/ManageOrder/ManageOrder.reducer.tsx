export const manageOrderReducer = (state: any, action: any) => {
    if (action.type == "updateOrderNumberList")
        return { orderNumberList: action.payload };
    return {};
};
