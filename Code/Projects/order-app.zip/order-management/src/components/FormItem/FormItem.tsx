import { changeCase } from "../../Services/utils";
import styles from "./FormItem.module.scss";
import { IFormItemProps } from "./FormItem.types";

const FormItem = ({ data, index, onChange, orderItems, optionList }: any) => {
    const inputs: any = Object.entries(data);
    return (
        <div className={styles["input-group"]}>
            <label htmlFor={index + inputs[0][0]}>
                {changeCase(inputs[0][0])}
            </label>
            <input
                placeholder="ex : Spring"
                id={index + inputs[0][0]}
                type="text"
                value={inputs[0][1]}
                name={inputs[0][0]}
                required
                onChange={(e) => {
                    onChange({
                        type: "updateItem",
                        payload: {
                            index: index,
                            name: inputs[0][0],
                            value: e.target.value,
                        },
                    });
                }}
            />
            {/*  --------------------------------------------------------  */}
            <label htmlFor={index + inputs[1][0]}>
                {changeCase(inputs[1][0])}
            </label>
            <input
                min={0.1}
                id={index + inputs[1][0]}
                type="number"
                value={inputs[1][1]}
                name={inputs[1][0]}
                step={0.1}
                required
                onChange={(e) => {
                    console.log(inputs[1][1]);
                    onChange({
                        type: "updateItem",
                        payload: {
                            index: index,
                            name: inputs[1][0],
                            value:
                                +e.target.value < 0.1 ? 0.1 : +e.target.value,
                            // value: e.target.value,
                        },
                    });
                }}
            />
            {/*  --------------------------------------------------------  */}
            <label htmlFor={index + inputs[2][0]}>
                {changeCase(inputs[2][0])}
            </label>
            <input
                min={0.1}
                step={0.1}
                id={index + inputs[2][0]}
                type="number"
                value={inputs[2][1]}
                name={inputs[2][0]}
                required
                onChange={(e) => {
                    onChange({
                        type: "updateItem",
                        payload: {
                            index: index,
                            name: inputs[2][0],
                            value: +e.target.value < 0.1 ? 0.1 : e.target.value,
                        },
                    });
                }}
            />
            {/*  --------------------------------------------------------  */}
            <label htmlFor={index + inputs[3][0]}>
                {changeCase(inputs[3][0])}
            </label>
            <input
                min={0.1}
                step={0.1}
                id={index + inputs[3][0]}
                type="number"
                value={inputs[3][1]}
                name={inputs[3][0]}
                required
                onChange={(e) => {
                    onChange({
                        type: "updateItem",
                        payload: {
                            index: index,
                            name: inputs[3][0],
                            value: +e.target.value < 0.1 ? 0.1 : e.target.value,
                        },
                    });
                }}
            />
            {/*  --------------------------------------------------------  */}
            <label htmlFor={index + inputs[4][0]}>
                {changeCase(inputs[4][0])}
            </label>
            <input
                min={1}
                step={0.1}
                id={index + inputs[4][0]}
                type="number"
                value={inputs[4][1]}
                name={inputs[4][0]}
                required
                onChange={(e) => {
                    onChange({
                        type: "updateItem",
                        payload: {
                            index: index,
                            name: inputs[4][0],
                            value: +e.target.value < 1 ? 1 : e.target.value,
                        },
                    });
                }}
            />
            {/*  --------------------------------------------------------  */}
            <label htmlFor={index + inputs[5][0]}>Material</label>
            <select
                name="material"
                id={index + inputs[5][0]}
                required
                value={inputs[5][1]}
                onChange={(e) => {
                    onChange({
                        type: "updateItem",
                        payload: {
                            index: index,
                            name: inputs[5][0],
                            value: e.target.value,
                        },
                    });
                }}
            >
                {optionList.map(({ name }: any) => (
                    <option value={name}>{name}</option>
                ))}
            </select>
            <button
                type="button"
                onClick={() => {
                    orderItems.splice(index, 1);
                    onChange({
                        type: "removeItem",
                        payload: [...orderItems],
                    });
                }}
                disabled={orderItems.length < 2}
            >
                Remove <i className="fa-solid fa-trash-can"></i>
            </button>
        </div>
    );
};
export default FormItem;
