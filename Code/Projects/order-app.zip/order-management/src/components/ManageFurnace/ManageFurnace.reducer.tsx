import FormComponent from "../FormComponent/FormComponent/FormComponent";
import { InputType } from "../FormComponent/FormComponent/FormComponent.types";

const formData: InputType[] = [
    {
        type: "text",
        required: true,
        name: "furnaceName",
        label: "Furnace Name",
        placeholder: "ex : Furnace 2",
    },
];

const generateEditFormField = (data: any): any => {
    const form: any = [];
    for (let element of formData) {
        const temp: any = { ...element };
        temp.defaultValue = data[temp.name];
        form.push(temp);
    }
    console.log(form);
    return form;
};

export const manageFurnaceReducer = (state: any, action: any) => {
    console.log(action.payload);
    if (action.type === "addFurnace") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => action.payload(e)}
                    formFields={formData}
                />
            ),
        };
    } else if (action.type === "editFurnace") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({ _id: action.payload["_id"], ...e });
                    }}
                    formFields={generateEditFormField(action.payload)}
                />
            ),
        };
    } else if (action.type === "deleteFurnace") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({
                            _id: action.payload["_id"],
                            ...e,
                        });
                    }}
                    formFields={[
                        {
                            type: "button",
                            label: "Are you sure ?",
                            name: "delete",
                            onClick: () => {},
                            attribute: { disabled: true },
                        },
                    ]}
                />
            ),
        };
    } else if (action.type === "updateTabel") {
        console.log(action.payload);
        if (action.payload.data) {
            return { ...state, data: action.payload };
        } else {
            return { ...state, data: null };
        }
    }
    return { ...state, open: action.open };
};
