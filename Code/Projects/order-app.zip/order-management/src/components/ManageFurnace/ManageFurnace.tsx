import { useReducer, useEffect } from "react";
import Header from "../Header/Header";
import PopUp from "../PopUp/PopUp";
import Tabel from "../Tabel/Tabel";
import { ITableActions } from "../Tabel/Tabel.types";
import styles from "./ManageFurnace.module.scss";
import { IManageFurnaceProps } from "./ManageFurnace.types";
import server from "../../Services/https";
import { manageFurnaceReducer } from "./ManageFurnace.reducer";

const columns = ["furnaceName"];

const ManageFurnace = () => {
    const [furnace, furnaceDispatch] = useReducer(manageFurnaceReducer, {
        type: "",
        open: false,
        payload: {},
        data: {},
    });

    const addFurnaceHandler = async (data: any) => {
        try {
            const res = await server.addFurnace(data);
            console.log(res);
            if (res.data.data) {
                furnaceDispatch({
                    open: false,
                    payload: {},
                });
                getFurnaceHandler();
            }
        } catch (error) {
            console.log(error);
        }
    };

    const getFurnaceHandler = async () => {
        try {
            const res = await server.getFurnace();
            console.log(res);
            furnaceDispatch({ type: "updateTabel", payload: res.data });
        } catch (error) {
            console.log(error);
        }
    };

    const editFurnaceHandler = async (data: any) => {
        console.log(data);
        try {
            const res = await server.editFurnace(data);
            console.log(res);
            if (res.data.data) {
                getFurnaceHandler();
                furnaceDispatch({
                    open: false,
                    payload: {},
                });
            }
        } catch (error) {
            console.log(error);
        }
    };
    const deleteFurnaceHandler = async (data: any) => {
        console.log(data);
        if (data) {
            try {
                const res = await server.deleteFurnace(data);
                console.log(res);
                if (res.data.data) {
                    getFurnaceHandler();
                    furnaceDispatch({
                        open: false,
                        payload: {},
                    });
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            getFurnaceHandler();
            furnaceDispatch({
                open: false,
                payload: {},
            });
        }
    };

    const actions: ITableActions = {
        edit: (index: any) => {
            furnaceDispatch({
                open: true,
                type: "editFurnace",
                payload: furnace.data.data[index],
                handler: editFurnaceHandler,
            });
            console.log(furnace.data.data[index]);
        },
        delete: (index: any) => {
            furnaceDispatch({
                open: true,
                type: "deleteFurnace",
                payload: furnace.data.data[index],
                handler: deleteFurnaceHandler,
            });
            console.log(furnace.data.data[index]);
        },
    };

    useEffect(() => {
        getFurnaceHandler();
    }, []);
    const addMaterial = (
        <>
            <button
                className={styles["add-btn"]}
                onClick={() => {
                    furnaceDispatch({
                        type: "addFurnace",
                        open: true,
                        payload: addFurnaceHandler,
                    });
                }}
            >
                Add Furnace
            </button>
        </>
    );
    return (
        <div className={styles["container"]}>
            {furnace.open && (
                <PopUp
                    closeHandler={() => {
                        furnaceDispatch({
                            open: false,
                            payload: {},
                        });
                    }}
                    JSX={furnace.payload}
                />
            )}
            <Header title={"Manage Customers"} JSX={addMaterial} />
            <div className={styles["tabel-container"]}>
                {Boolean(furnace.data.data) && (
                    <Tabel
                        columns={columns}
                        data={furnace.data}
                        actions={actions}
                    />
                )}
            </div>
        </div>
    );
};
export default ManageFurnace;
