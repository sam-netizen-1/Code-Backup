import styles from "./Header.module.scss";
import { IHeaderProps } from "./Header.types";

const Header = ({ JSX, title }: IHeaderProps) => {
    return (
        <header className={styles.header}>
            <h3>{title}</h3>
            {JSX && <div className={styles.container}>{JSX}</div>}
        </header>
    );
};
export default Header;
