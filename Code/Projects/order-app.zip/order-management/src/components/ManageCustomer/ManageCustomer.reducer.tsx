import FormComponent from "../FormComponent/FormComponent/FormComponent";
import { InputType } from "../FormComponent/FormComponent/FormComponent.types";

const formData: InputType[] = [
    {
        type: "text",
        required: true,
        name: "clientName",
        label: "Company Name",
        placeholder: "ex : Hydrabadi Biryani",
    },
    {
        type: "select",
        name: "clientState",
        label: "State",
        defaultValue: "MH",
        options: [
            { value: "MH", label: "Maharastra" },
            { value: "GU", label: "Gujrat" },
            {
                value: "MP",
                label: "Madhya Pradesh",
            },
            {
                value: "KR",
                label: "Karnatak",
            },
            {
                value: "PU",
                label: "Punjab",
            },
            {
                value: "HR",
                label: "Haryana",
            },
        ],
    },
    {
        type: "text",
        label: "Shipping : Address",
        name: "shippingAddress",
        required: true,
        placeholder: "ex : Nagpur, Buldi, block no : 6",
    },
    {
        type: "text",
        label: "Billing : Address ",
        name: "billingAddress",
        required: true,
        placeholder: "ex : Nagpur, Buldi, block no : 6",
    },
];

const generateEditFormField = (data: any): any => {
    // console.log(data);
    const form: any = [];
    for (let element of formData) {
        const temp: any = { ...element };
        temp.defaultValue = data[temp.name];
        form.push(temp);
    }
    console.log(form);
    return form;
};

export const manageCustomerReducer = (state: any, action: any) => {
    console.log(action.payload);
    if (action.type === "addCustomer") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => action.payload(e)}
                    formFields={formData}
                />
            ),
        };
    } else if (action.type === "editUser") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({ _id: action.payload["_id"], ...e });
                    }}
                    formFields={generateEditFormField(action.payload)}
                />
            ),
        };
    } else if (action.type === "deleteUser") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({ _id: action.payload["_id"], ...e });
                    }}
                    formFields={[
                        {
                            type: "button",
                            label: "Are you sure ?",
                            name: "delete",
                            onClick: () => {},
                            attribute: { disabled: true },
                        },
                    ]}
                />
            ),
        };
    } else if (action.type === "updateTabel") {
        console.log(action.payload);
        if (action.payload.data) {
            return { ...state, data: action.payload };
        } else {
            return { ...state, data: null };
        }
    }
    return { ...state, open: action.open };
};
