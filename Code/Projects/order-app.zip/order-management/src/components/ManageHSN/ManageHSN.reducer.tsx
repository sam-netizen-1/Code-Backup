import FormComponent from "../FormComponent/FormComponent/FormComponent";
import { InputType } from "../FormComponent/FormComponent/FormComponent.types";

const formData: InputType[] = [
    {
        type: "number",
        required: true,
        name: "hsnCode",
        label: "HSN Code",
        placeholder: "ex : 1010",
    },

    {
        type: "number",
        label: "SGST",
        name: "sgst",
        required: true,
        placeholder: "1",
        attribute: { min: 0 },
    },
    {
        type: "number",
        label: "CGST",
        name: "cgst",
        required: true,
        placeholder: "1",
        attribute: { min: 0 },
    },
    {
        type: "number",
        label: "IGST",
        name: "igst",
        required: true,
        placeholder: "1",
        attribute: { min: 0 },
    },
    {
        type: "text",
        label: "Good Type",
        name: "goodType",
        required: true,
        placeholder: "ex : Iron Bar",
    },
];

const generateEditFormField = (data: any): any => {
    const form: any = [];
    for (let element of formData) {
        const temp: any = { ...element };
        temp.defaultValue = data[temp.name];
        form.push(temp);
    }
    console.log(form);
    return form;
};

export const manageHsnReducer = (state: any, action: any) => {
    console.log(action.payload);
    if (action.type === "addHsn") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => action.payload(e)}
                    formFields={formData}
                />
            ),
        };
    } else if (action.type === "editHsn") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({ _id: action.payload["_id"], ...e });
                    }}
                    formFields={generateEditFormField(action.payload)}
                />
            ),
        };
    } else if (action.type === "deleteHsn") {
        return {
            ...state,
            open: true,
            payload: (
                <FormComponent
                    formDetail={(e) => {
                        action.handler({
                            _id: action.payload["_id"],
                            ...e,
                        });
                    }}
                    formFields={[
                        {
                            type: "button",
                            label: "Are you sure ?",
                            name: "delete",
                            onClick: () => {},
                            attribute: { disabled: true },
                        },
                    ]}
                />
            ),
        };
    } else if (action.type === "updateTabel") {
        console.log(action.payload);
        if (action.payload.data) {
            return { ...state, data: action.payload };
        } else {
            return { ...state, data: null };
        }
    }
    return { ...state, open: action.open };
};
