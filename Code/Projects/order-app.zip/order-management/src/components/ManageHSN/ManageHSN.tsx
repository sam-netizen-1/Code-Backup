import { useReducer, useEffect } from "react";
import Header from "../Header/Header";
import PopUp from "../PopUp/PopUp";
import Tabel from "../Tabel/Tabel";
import { ITableActions } from "../Tabel/Tabel.types";
import styles from "./ManageHSN.module.scss";
import { IManageHSNProps } from "./ManageHSN.types";
import server from "../../Services/https";
import { manageHsnReducer } from "./ManageHSN.reducer";

const columns = ["hsnCode", "goodType", "sgst", "cgst", "igst"];

const ManageHSN = () => {
    const [hsn, setHsn] = useReducer(manageHsnReducer, {
        type: "",
        open: false,
        payload: {},
        data: {},
    });

    const addHSNHandler = async (data: any) => {
        try {
            const res = await server.addHSN(data);
            console.log(res);
            if (res.data.data) {
                setHsn({
                    open: false,
                    payload: {},
                });
                getHSNHandler();
            }
        } catch (error) {
            console.log(error);
        }
    };

    const getHSNHandler = async () => {
        try {
            const res = await server.getHSN();
            console.log(res);
            setHsn({ type: "updateTabel", payload: res.data });
        } catch (error) {
            console.log(error);
        }
    };

    const editHsnHandler = async (data: any) => {
        console.log(data);
        try {
            const res = await server.editHSN(data);
            console.log(res);
            if (res.data.data) {
                getHSNHandler();
                setHsn({
                    open: false,
                    payload: {},
                });
            }
        } catch (error) {
            console.log(error);
        }
    };
    const deleteHsnHandler = async (data: any) => {
        console.log(data);
        if (data) {
            try {
                const res = await server.deleteHSN(data);
                console.log(res);
                if (res.data.data) {
                    getHSNHandler();
                    setHsn({
                        open: false,
                        payload: {},
                    });
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            getHSNHandler();
            setHsn({
                open: false,
                payload: {},
            });
        }
    };

    const actions: ITableActions = {
        edit: (index: any) => {
            setHsn({
                open: true,
                type: "editHsn",
                payload: hsn.data.data[index],
                handler: editHsnHandler,
            });
            console.log(hsn.data.data[index]);
        },
        delete: (index: any) => {
            setHsn({
                open: true,
                type: "deleteHsn",
                payload: hsn.data.data[index],
                handler: deleteHsnHandler,
            });
            console.log(hsn.data.data[index]);
        },
    };

    useEffect(() => {
        getHSNHandler();
    }, []);
    const addMaterial = (
        <>
            <button
                className={styles["add-btn"]}
                onClick={() => {
                    setHsn({
                        type: "addHsn",
                        open: true,
                        payload: addHSNHandler,
                    });
                }}
            >
                Add HSN
            </button>
        </>
    );
    return (
        <div className={styles["container"]}>
            {hsn.open && (
                <PopUp
                    closeHandler={() => {
                        setHsn({
                            open: false,
                            payload: {},
                        });
                    }}
                    JSX={hsn.payload}
                />
            )}
            <Header title={"Manage Customers"} JSX={addMaterial} />
            <div className={styles["tabel-container"]}>
                {Boolean(hsn.data.data) && (
                    <Tabel
                        columns={columns}
                        data={hsn.data}
                        actions={actions}
                    />
                )}
            </div>
        </div>
    );
};
export default ManageHSN;
