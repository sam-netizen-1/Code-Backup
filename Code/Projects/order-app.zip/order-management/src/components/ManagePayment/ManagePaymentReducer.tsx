export const manageOrderNumberReducer = (state: any, action: any) => {
    return action.payload;
};
