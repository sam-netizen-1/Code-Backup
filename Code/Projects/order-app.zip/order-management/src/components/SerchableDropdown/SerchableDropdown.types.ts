export interface ISerchableDropdownProps {
    name: string;
    itemsList: string[];
}
