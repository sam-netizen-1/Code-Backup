export interface ITabelProps {
    columns: string[];
    data: any;
    actions?: ITableActions;
    pagination?: ({}: any) => void;
}

export interface ITableActions {
    edit: (reference: any) => void;
    delete: (reference: any) => void;
    // reference: string;
}
