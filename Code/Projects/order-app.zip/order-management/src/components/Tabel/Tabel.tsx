import { changeCase } from "../../Services/utils";
import styles from "./Tabel.module.scss";
import { ITabelProps } from "./Tabel.types";

const Tabel = ({ columns, data, actions, pagination }: ITabelProps) => {
    // console.log(data.data);
    return (
        <section className={styles["table-container"]}>
            {data.data && (
                <section className={styles.table}>
                    <table>
                        <thead>
                            <tr>
                                {columns.map((element) => (
                                    <th>{changeCase(element)}</th>
                                ))}
                                {actions && (
                                    <th className={styles["action-heading"]}>
                                        Action
                                    </th>
                                )}
                            </tr>
                        </thead>
                        <tbody>
                            {data.data.map((item: any, index: number) => (
                                <tr>
                                    {columns.map((key) => (
                                        <td>{item[key]}</td>
                                    ))}
                                    {actions && (
                                        <td
                                            className={
                                                styles["action-btn-container"]
                                            }
                                        >
                                            <button
                                                className={styles["action-btn"]}
                                                onClick={() =>
                                                    actions.edit(
                                                        // item[actions.reference],
                                                        index
                                                    )
                                                }
                                            >
                                                Edit
                                            </button>
                                            <button
                                                className={styles["action-btn"]}
                                                onClick={() =>
                                                    actions.delete(
                                                        // item[actions.reference],
                                                        index
                                                    )
                                                }
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </section>
            )}
            <div className={styles["pagination"]}>
                <label htmlFor="page-size">Page Size</label>
                <select
                    id="page-size"
                    value={data.pageSize}
                    onChange={(e) => {
                        if (pagination) {
                            pagination({
                                type: "countChange",
                                payload: e.target.value,
                            });
                        }
                    }}
                >
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="75">75</option>
                </select>
                <button
                    disabled={!data.prev}
                    onClick={(e) => {
                        if (pagination) {
                            pagination({
                                type: "prev",
                            });
                        }
                    }}
                >
                    <i className="fa-solid fa-angles-left"></i>
                </button>
                <h3>{data.currentPage}</h3>
                <button
                    disabled={!data.next}
                    onClick={(e) => {
                        if (pagination) {
                            pagination({
                                type: "next",
                            });
                        }
                    }}
                >
                    <i className="fa-solid fa-angles-right"></i>
                </button>
            </div>
        </section>
    );
};
export default Tabel;
