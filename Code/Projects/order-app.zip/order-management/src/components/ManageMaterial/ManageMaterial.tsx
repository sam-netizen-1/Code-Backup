import { useEffect, useReducer } from "react";
import Header from "../Header/Header";
import PopUp from "../PopUp/PopUp";
import Tabel from "../Tabel/Tabel";
import styles from "./ManageMaterial.module.scss";
import { manageMaterialReducer } from "./ManageMaterial.reducer";
import { IManageMaterialProps } from "./ManageMaterial.types";
import server from "../../Services/https";
import { ITableActions } from "../Tabel/Tabel.types";

const columns = ["materialName", "pricePerKg", "description"];

const ManageMaterial = () => {
    const [material, setMaterial] = useReducer(manageMaterialReducer, {
        type: "",
        open: false,
        payload: {},
        data: {},
    });

    const addMaterialHandler = async (data: any) => {
        try {
            const res = await server.addMaterial(data);
            console.log(res);
            if (res.data.data) {
                setMaterial({
                    open: false,
                    payload: {},
                });
                getMaterialHandler();
            }
        } catch (error) {
            console.log(error);
        }
    };

    const getMaterialHandler = async () => {
        try {
            const res = await server.getMaterial();
            console.log(res);
            setMaterial({ type: "updateTabel", payload: res.data });
        } catch (error) {
            console.log(error);
        }
    };

    const editMaterialHandler = async (data: any) => {
        console.log(data);
        try {
            const res = await server.editMaterial(data);
            console.log(res);
            if (res.data.data) {
                getMaterialHandler();
                setMaterial({
                    open: false,
                    payload: {},
                });
            }
        } catch (error) {
            console.log(error);
        }
    };
    const deleteMaterialHandler = async (data: any) => {
        console.log(data);
        if (data) {
            try {
                const res = await server.deleteMaterial(data);
                console.log(res);
                if (res.data.data) {
                    getMaterialHandler();
                    setMaterial({
                        open: false,
                        payload: {},
                    });
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            getMaterialHandler();
            setMaterial({
                open: false,
                payload: {},
            });
        }
    };

    const actions: ITableActions = {
        edit: (index: any) => {
            setMaterial({
                open: true,
                type: "editMaterial",
                payload: material.data.data[index],
                handler: editMaterialHandler,
            });
            console.log(material.data.data[index]);
        },
        delete: (index: any) => {
            setMaterial({
                open: true,
                type: "deleteMaterial",
                payload: material.data.data[index],
                handler: deleteMaterialHandler,
            });
            console.log(material.data.data[index]);
        },
    };

    useEffect(() => {
        getMaterialHandler();
    }, []);
    const addMaterial = (
        <>
            <button
                className={styles["add-btn"]}
                onClick={() => {
                    setMaterial({
                        type: "addMaterial",
                        open: true,
                        payload: addMaterialHandler,
                    });
                }}
            >
                Add Material
            </button>
        </>
    );
    return (
        <div className={styles["container"]}>
            {material.open && (
                <PopUp
                    closeHandler={() => {
                        setMaterial({
                            open: false,
                            payload: {},
                        });
                    }}
                    JSX={material.payload}
                />
            )}
            <Header title={"Manage Customers"} JSX={addMaterial} />
            <div className={styles["tabel-container"]}>
                {Boolean(material.data.data) && (
                    <Tabel
                        columns={columns}
                        data={material.data}
                        actions={actions}
                    />
                )}
            </div>
        </div>
    );
};
export default ManageMaterial;
