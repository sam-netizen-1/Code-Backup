import { useReducer } from "react";
import FormComponent from "../FormComponent/FormComponent/FormComponent";
import Header from "../Header/Header";
import PopUp from "../PopUp/PopUp";
import Tabel from "../Tabel/Tabel";
import styles from "./ManageUsers.module.scss";
import { formReducer } from "./ManageUsers.reducer";
import { IManageUsersProps } from "./ManageUsers.types";
import server from "../../Services/https";

const data = {
    data: [
        {
            username: "Ramesh",
            role: "Accountant",
            email: "ramesh@gmail.com",
            active: "Active",
            createdOn: "2021-June-19",
        },
        {
            username: "Ramesh",
            role: "Accountant",
            email: "ramesh@gmail.com",
            createdOn: "2021-June-19",
            active: "Active",
        },
        {
            username: "Ramesh",
            role: "Accountant",
            email: "ramesh@gmail.com",
            createdOn: "2021-June-19",
            active: "Active",
        },
        {
            username: "Ramesh",
            role: "Accountant",
            email: "ramesh@gmail.com",
            createdOn: "2021-June-19",
            active: "Active",
        },
        {
            username: "Ramesh",
            role: "Accountant",
            email: "ramesh@gmail.com",
            createdOn: "2021-June-19",
            active: "Active",
        },
        {
            username: "Ramesh",
            role: "Accountant",
            email: "ramesh@gmail.com",
            createdOn: "2021-June-19",
            active: "Active",
        },
        {
            username: "Suresh",
            role: "Clerk",
            email: "suresh@gmail.com",
            createdOn: "2021-June-19",
            active: "Active",
        },
        {
            username: "Mahesh",
            role: "Clerk",
            email: "mahesh@gmail.com",
            createdOn: "2021-June-19",
            active: "Inactive",
        },
    ],
    currentPage: "4",
    next: "true",
    prev: "",
    pageSize: "25",
};

// const form = (
//     <FormComponent
//         reset
//         formFields={[{ type: "text", label: "username", name: "username" }]}
//         formDetail={(obj) => console.table(obj)}
//     />
// );

const ManageUsers = () => {
    const [form, formDispatcher] = useReducer(formReducer, {
        type: false,
        payload: <></>,
    });

    const actions = {
        edit: (reference: number) =>
            formDispatcher({
                type: "editUser",
                payload: data.data[reference],
                submit: formDispatcher,
            }),
        delete: (reference: number) => console.table(reference),
    };

    const addUser = async (obj: any) => {
        try {
            const res = await server.addUser(obj);
            console.log(res);
            formDispatcher({ type: "submit" });
        } catch (error) {
            console.log(error);
        }
    };

    const AddUserBtn = (
        <button
            className={styles["add-user-btn"]}
            onClick={() =>
                formDispatcher({
                    type: "addUser",
                    submit: addUser,
                })
            }
        >
            Add User <i className="fa-solid fa-user-plus"></i>
        </button>
    );
    console.log(form);

    return (
        <div className={styles.container}>
            {form.type && (
                <PopUp
                    closeHandler={() => formDispatcher({ type: false })}
                    JSX={form.payload}
                />
            )}
            <Header title="Manage User" JSX={AddUserBtn} />
            <Tabel
                columns={["username", "email", "role", "active", "createdOn"]}
                data={data}
                // pagination={}
                actions={actions}
            />
        </div>
    );
};
export default ManageUsers;
