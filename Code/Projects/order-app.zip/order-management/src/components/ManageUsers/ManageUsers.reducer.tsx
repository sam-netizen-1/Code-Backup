import { changeCase } from "../../Services/utils";
import FormComponent from "../FormComponent/FormComponent/FormComponent";

export const generateFormField = (data: any): any => {
    return Object.entries(data).map((field) => ({
        defaultValue: field[1],
        type: "text",
        label: changeCase(field[0]),
        name: field[0],
    }));
};

export const formReducer = (state: any, action: any) => {
    if (action.type === "editUser") {
        return {
            type: true,
            payload: (
                <FormComponent
                    formFields={generateFormField(action.payload)}
                    formDetail={(obj) => {
                        console.table(obj);
                        action.submit({ type: "submit" });
                    }}
                />
            ),
        };
    } else if (action.type === "addUser") {
        return {
            type: true,
            payload: (
                <FormComponent
                    formFields={[
                        {
                            type: "text",
                            label: "Username",
                            name: "name",
                            required: true,
                        },
                        {
                            type: "text",
                            label: "Email",
                            name: "email",
                            required: true,
                        },
                        {
                            type: "select",
                            label: "Role",
                            name: "roleId",
                            required: true,
                            defaultValue: "",
                            options: [
                                { value: "", label: "Select a role" },
                                { value: "id_clerk", label: "Clerk" },
                                { value: "id_accountant", label: "Accountant" },
                            ],
                        },
                    ]}
                    formDetail={(obj) => {
                        console.table(obj);
                        // action.submit({ type: "submit" });
                        action.submit(obj);
                    }}
                />
            ),
        };
    } else if (action.type === "submit") {
        return { type: false };
    }
    return action;
};
