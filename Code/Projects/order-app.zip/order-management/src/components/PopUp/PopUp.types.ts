export interface IPopUpProps {
    JSX: JSX.Element;
    closeHandler: () => void;
}
