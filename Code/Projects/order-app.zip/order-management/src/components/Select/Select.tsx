import { useEffect, useState } from "react";
import styles from "./Select.module.scss";
import { ISelectProps } from "./Select.types";

const Select = ({ label, name, options, value, onChange }: ISelectProps) => {
    return (
        <div className={styles.select}>
            <label htmlFor={label + name}>{label}</label>
            <select
                id={label + name}
                name={name}
                value={value}
                onChange={(e) => onChange(e.target.value)}
            >
                {options.map(({ label, value }) => (
                    <option key={label + value} value={value}>
                        {label}
                    </option>
                ))}
            </select>
        </div>
    );
};
export default Select;
