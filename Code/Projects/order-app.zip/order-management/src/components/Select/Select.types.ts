export interface ISelectProps {
    type: "select";
    label: string;
    name: string;
    options: IOptions[];
    value: string;
    onChange: (e: any) => void;
}
interface IAttribute {
    [name: string]: string | boolean | number;
}
interface IOptions {
    value: string;
    label: string;
}
