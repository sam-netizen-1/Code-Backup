let storage = {};

export const dashboardHomeReducer = (state: any, action: any) => {
    if (action.type === "INIT") {
        storage = action.payload;
        return action.payload;
    }
    if (action.type === "ALL") {
        return { ...storage };
    }
    return action.payload;
};

export const dashboardFilterReducer = (state: any, action: any) => {
    return action;
};

export const dashboardPaginateReducer = (state: any, action: any) => {
    if (action.type == "next") {
        return {
            pageNo: state.pageNo + 1,
            pageCount: state.pageCount,
        };
    } else if (action.type == "prev") {
        return {
            pageNo: state.pageNo - 1,
            pageCount: state.pageCount,
        };
    } else if (action.type == "countChange") {
        return {
            pageNo: state.pageNo,
            pageCount: action.payload,
        };
    }
    return action;
};
