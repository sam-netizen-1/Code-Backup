import { IButtonProps } from "../Button/Button.types";
import { ICheckBoxProps } from "../CheckBox/CheckBox.types";
import { IInputProps } from "../Input/Input.types";
import { IRadioBtnsProps } from "../RadioBtns/RadioBtns.types";
import { ISelectProps } from "../Select/Select.types";

export interface IFormComponentProps {
    formDetail: (obj: { [key: string]: string }) => void;
    formFields: InputType[];
    reset?: true | boolean | undefined;
}
export type InputType =
    | IInputProps
    | ISelectProps
    | IRadioBtnsProps
    | ICheckBoxProps
    | IButtonProps;
