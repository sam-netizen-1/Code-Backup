import { useEffect, useState } from "react";
import styles from "./Select.module.scss";
import { ISelectProps } from "./Select.types";

const Select = ({
    label,
    name,
    options,
    required,
    attribute,
    defaultValue,
    reset,
    disabled,
}: ISelectProps) => {
    const [value, setValue] = useState(
        defaultValue != undefined ? defaultValue : options[0].value
    );

    useEffect(() => {
        setValue(defaultValue != undefined ? defaultValue : options[0].value);
    }, [reset]);

    return (
        <div className={styles.select}>
            <label htmlFor={label + name}>{label}</label>
            <select
                disabled={disabled}
                id={label + name}
                name={name}
                {...attribute}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                required={required}
            >
                {options.map(({ label, value }) => (
                    <option key={label + value} value={value}>
                        {label}
                    </option>
                ))}
            </select>
        </div>
    );
};
export default Select;
