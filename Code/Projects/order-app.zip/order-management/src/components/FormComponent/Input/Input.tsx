import { InputHTMLAttributes, useEffect, useState } from "react";

import styles from "./Input.module.scss";
import { IInputProps } from "./Input.types";

const Input = ({
    type,
    defaultValue,
    label,
    placeholder,
    name,
    attribute,
    required,
    reset,
}: IInputProps) => {
    const [value, setValue] = useState<any>(defaultValue ? defaultValue : "");

    useEffect(() => {
        if (type == "file") {
            console.log("first");
            setValue("");
        } else {
            setValue(defaultValue ? defaultValue : "");
        }
    }, [reset]);

    return (
        <div className={styles.input}>
            <label htmlFor={label + type}>{label}</label>
            <input
                {...attribute}
                name={name}
                onChange={(e) => setValue(e.currentTarget.value)}
                id={label + type}
                type={type}
                placeholder={placeholder}
                value={value}
                required={required}
            />
        </div>
    );
};
export default Input;
