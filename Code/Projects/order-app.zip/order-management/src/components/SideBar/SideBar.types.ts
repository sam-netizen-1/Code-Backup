export interface ISideBarProps {
    SideBarItems: ISideBarItem[];
    navigator: (string: string) => void;
}

export type ISideBarItem = {
    label: string;
    icon: string;
    navigateTo: string;
};
