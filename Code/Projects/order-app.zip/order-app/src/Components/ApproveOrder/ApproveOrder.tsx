import { useEffect, useState } from "react";
import { getPendingOrdersData } from "../../Services/Methods/Admin.Services";

const ApproveOrder = () => {
  const [pendingOrders, setPendingOrders] = useState([]);
  const getData = async () => {
    const res = await getPendingOrdersData();
    return res;
  };
  // useEffect(() => {
  //   setPendingOrders(getData());
  // });
  return <></>;
};
export default ApproveOrder;
