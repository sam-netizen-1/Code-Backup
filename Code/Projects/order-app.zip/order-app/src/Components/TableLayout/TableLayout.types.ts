export interface ILayoutProps {
    pageNumber : number,
    pageSize : number,
    mockData: {
        books: {
            id: number;
            name: string;
            author: string;
            price: number;
            dateOfPublication: number;
        };
        totalPages: number;
        nextPage: boolean;
        prevPage: boolean;
    }
}