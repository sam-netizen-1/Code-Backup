import { createContext, useEffect, useReducer } from "react";
import styles from "./TableLayout.module.scss";
import Table from "../Table/Table";
import AddModal from "../Modal/AddModal";
import { tableLayoutReducer } from "./TableLayout.reducer";
import EditModal from "../Modal/EditModal";
import DeleteModal from "../Modal/DeleteModal";
import { getData } from "../../Services/Methods/Admin.Services";
export const TableContext = createContext<any>({});
export default function TableLayout({ url, columns }: any) {
  let data: any = [];
  const setData = async () => {
    data = await getData(url);
    tableLayoutDispatch({ type: "updateData", payload: data });
  };

  const [tableLayout, tableLayoutDispatch] = useReducer(tableLayoutReducer, {
    data: data,
    columns: columns,
    modal: {
      edit: -1,
      delete: -1,
      add: false,
    },
    reload: "true",
    url: url,
    dataHandler: (index: number) => (
      <div>
        <button
          onClick={() =>
            tableLayoutDispatch({ type: "showEdit", payload: index })
          }
        >
          Edit
        </button>
        <button
          onClick={() =>
            tableLayoutDispatch({ type: "showDelete", payload: index })
          }
        >
          Delete
        </button>
      </div>
    ),
  });

  useEffect(() => {
    setData();
  }, [tableLayout.modal]);

  return (
    <TableContext.Provider
      value={{
        tableLayout: tableLayout,
        tableLayoutDispatch: tableLayoutDispatch,
        url: url,
      }}
    >
      <div className={styles.container}>
        <main className={styles.tableLayout}>
          <button
            className={styles.addBtn}
            onClick={() => {
              tableLayoutDispatch({ type: "showAdd", payload: true });
            }}
          >
            Add
          </button>
          <Table />
        </main>
        {tableLayout.modal.edit !== -1 && <EditModal />}
        {tableLayout.modal.delete !== -1 && <DeleteModal />}
        {tableLayout.modal.add && <AddModal />}
      </div>
    </TableContext.Provider>
  );
}
