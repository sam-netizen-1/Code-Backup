export const tableLayoutReducer = (state: any, action: any) => {
  if (action.type === "showEdit") {
    const modal = state.modal;
    modal.edit = action.payload;
    return { ...state, modal: { ...modal } };
  }
  if (action.type === "showAdd") {
    const modal = state.modal;
    modal.add = action.payload;
    return { ...state, modal: { ...modal } };
  }
  if (action.type === "showDelete") {
    const modal = state.modal;
    modal.delete = action.payload;
    return { ...state, modal: { ...modal } };
  }
  if (action.type === "updateData") {
    let newdata = state.data;
    newdata = action.payload;
    return { ...state, data: [...newdata] };
  }
  return state;
};
