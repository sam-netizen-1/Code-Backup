import { Field, Form, Formik } from "formik";
import { forgotPassword } from "../../Services/Methods/Auth.Services";
import styles from "./ForgetPassword.module.scss";
const ForgetPassword = () => {
  const clickFunction = async (data: { email: string }) => {
    const res = await forgotPassword(data);
    console.log(res);
  };
  return (
    <Formik
      initialValues={{ email: "", password: "" }}
      onSubmit={(values) => {
        clickFunction(values);
      }}
    >
      <Form className={styles.forgetPassword_box}>
        <span className={styles.title}>Forget Password</span>
        <Field
          required
          placeholder="Email"
          className={styles.input}
          name="email"
          type="email"
        />
        <button className={styles.submit_button} type="submit">
          Submit
        </button>
      </Form>
    </Formik>
  );
};

export default ForgetPassword;
