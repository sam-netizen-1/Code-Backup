import TableLayout from "../TableLayout/TableLayout";

const ManageHSN = () => {
  return (
    <>
      <TableLayout
        columns={["HSN_Code", "description", "CGST", "SGST", "IGST"]}
        url={"HSN"}
      />
    </>
  );
};

export default ManageHSN;
