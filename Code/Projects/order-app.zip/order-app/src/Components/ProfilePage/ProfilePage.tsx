import { useContext } from "react";
import { MainContext } from "../../Pages/Main/Main";
import styles from "./ProfilePage.module.scss";
import { Formik, Form, Field } from "formik";
import { changePassword } from "../../Services/Methods/Auth.Services";

const ProfilePage = () => {
  const { userId } = useContext(MainContext);
  const submitHandler = async (data: any) => {
    const res = await changePassword(userId, data);
    console.log(res);
  };
  return (
    <Formik
      initialValues={{
        oldPassword: "",
        newPassword: "",
        confirmNewPassword: "",
      }}
      onSubmit={(values) => {
        submitHandler(values);
      }}
    >
      <Form className={styles.profile}>
        <h3 className={styles.title}>Change Password</h3>
        <Field
          required
          className={styles.input}
          name="oldPassword"
          type="text"
          placeholder="Old Password"
        />
        <Field
          required
          className={styles.input}
          name="newPassword"
          type="text"
          placeholder="New Password"
        />
        <Field
          required
          className={styles.input}
          name="confirmNewPassword"
          type="text"
          placeholder="Confirm New Password"
        />
        <button type="submit" className={styles.submit_button}>
          Submit
        </button>
      </Form>
    </Formik>
  );
};
export default ProfilePage;
