import TableLayout from "../TableLayout/TableLayout";

const ManageStorages = () => {
  return (
    <>
      <TableLayout columns={["building", "shelf", "rack"]} url={"storage"} />
    </>
  );
};

export default ManageStorages;
