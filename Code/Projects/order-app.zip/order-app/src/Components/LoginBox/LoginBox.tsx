import { useContext } from "react";
import { MainContext } from "../../Pages/Main/Main";
import { login } from "../../Services/Methods/Auth.Services";
import { Formik, Form, Field } from "formik";
import styles from "./LoginBox.module.scss";
const role: any = {
  "635fb524e962be0f00a95d70": "Admin",
  "635fb524e962be0f00a95d72": "Clerk",
  "635fb524e962be0f00a95d71": "Accountant",
};
const LoginBox = () => {
  const { pageDispatch, setUserId } = useContext(MainContext);

  const clickFunction = async (data: { email: string; password: string }) => {
    const res = await login(data);
    if (res.roleId) {
      pageDispatch({ type: "change", payload: role[res.roleId] });
    }
    if (res.userId) {
      setUserId(res.userId);
    }
  };
  return (
    <Formik
      initialValues={{ email: "", password: "" }}
      onSubmit={(values) => {
        clickFunction(values);
      }}
    >
      <Form className={styles.login_box}>
        <span className={styles.title}>Login</span>
        <Field
          required
          placeholder="Email"
          className={styles.input}
          name="email"
          type="email"
        />
        <Field
          required
          placeholder="Password"
          className={styles.input}
          name="password"
          type="password"
        />
        <button className={styles.login_button} type="submit">
          Login
        </button>
      </Form>
    </Formik>
  );
};
export default LoginBox;
