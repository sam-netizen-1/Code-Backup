import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { MainContext } from "../../Pages/Main/Main";
import { logout } from "../../Services/Methods/Auth.Services";
import styles from "./SideBar.module.scss";
const SideBar = ({ sideBar }: any) => {
  const { pageDispatch } = useContext(MainContext);
  const navigate = useNavigate();
  const navigateTo = (path: string) => {
    navigate(path);
  };
  const handleLogout = async () => {
    const res = await logout();
    console.log(res);
    pageDispatch({ type: "change", payload: "Auth" });
    navigateTo("/");
  };
  return (
    <>
      {sideBar && (
        <div className={styles.sideBar}>
          {sideBar.map((s: any) => (
            <button
              key={s.path}
              className={styles.button}
              onClick={() => {
                navigateTo(s.path);
              }}
            >
              {s.name}
            </button>
          ))}{" "}
          <button className={styles.button} onClick={handleLogout}>
            {" "}
            Logout{" "}
          </button>
        </div>
      )}
    </>
  );
};
export default SideBar;
