import TableLayout from "../TableLayout/TableLayout";

const ManageUsers = () => {
  return (
    <>
      <TableLayout
        columns={["name", "username", "email", "role"]}
        url={"user"}
      />
    </>
  );
};

export default ManageUsers;
