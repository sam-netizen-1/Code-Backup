import TableLayout from "../TableLayout/TableLayout";

const ManageUnits = () => {
  return (
    <>
      <TableLayout columns={["name"]} url={"unit"} />
    </>
  );
};

export default ManageUnits;
