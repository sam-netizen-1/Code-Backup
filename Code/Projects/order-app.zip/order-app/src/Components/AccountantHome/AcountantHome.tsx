const AccountantHome = () => {
  return <></>;
};
export default AccountantHome;
