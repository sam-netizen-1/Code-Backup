import { Field, Form, Formik } from "formik";
import { useContext } from "react";
import { editData } from "../../Services/Methods/Admin.Services";
import { TableContext } from "../TableLayout/TableLayout";
import styles from "./Modal.module.scss";

export default function EditModal() {
  const { tableLayout, tableLayoutDispatch } = useContext(TableContext);
  const currentData = tableLayout.data[tableLayout.modal.edit];
  const initvalue: any = {};
  tableLayout.columns.forEach(
    (name: any) => (initvalue[name] = currentData[name])
  );
  return (
    <div className={styles.container}>
      <button
        onClick={() => tableLayoutDispatch({ type: "showEdit", payload: -1 })}
      >
        Close
      </button>
      <Formik
        initialValues={initvalue}
        onSubmit={async (values) => {
          const res = await editData(values, tableLayout.url, currentData._id);
          console.log(res);
          tableLayoutDispatch({ type: "showEdit", payload: -1 });
        }}
      >
        <Form className={styles.form}>
          {tableLayout.columns.map((key: string) => {
            return (
              <div>
                <label>{key.toUpperCase()}</label>
                <Field name={key} className={styles.input} />
              </div>
            );
          })}
          <button type="submit">Submit</button>
        </Form>
      </Formik>
    </div>
  );
}
