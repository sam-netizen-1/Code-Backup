export interface IModalProps{

}