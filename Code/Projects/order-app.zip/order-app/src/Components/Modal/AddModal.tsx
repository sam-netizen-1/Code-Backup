import { Field, Form, Formik } from "formik";
import { useContext } from "react";
import { addData } from "../../Services/Methods/Admin.Services";
import { TableContext } from "../TableLayout/TableLayout";
import styles from "./Modal.module.scss";

export default function AddModal() {
  const { tableLayout, tableLayoutDispatch } = useContext(TableContext);
  const initvalue: any = {};
  tableLayout.columns.forEach((name: any) => (initvalue[name] = ""));
  return (
    <div className={styles.container}>
      <button
        onClick={() => tableLayoutDispatch({ type: "showAdd", payload: false })}
      >
        Close
      </button>
      <Formik
        initialValues={initvalue}
        onSubmit={async (values) => {
          const res = await addData(values, tableLayout.url);
          console.log(res);
          tableLayoutDispatch({ type: "showAdd", payload: false });
        }}
      >
        <Form className={styles.form}>
          {tableLayout.columns.map((key: string) => {
            return (
              <div>
                <label>{key.toUpperCase()}</label>
                <Field name={key} type="text" className={styles.input} />
              </div>
            );
          })}
          <button type="submit">Submit</button>
        </Form>
      </Formik>
    </div>
  );
}
