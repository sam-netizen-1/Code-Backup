import { useContext } from "react";
import { deleteData } from "../../Services/Methods/Admin.Services";
import { TableContext } from "../TableLayout/TableLayout";
import styles from "./Modal.module.scss";

export default function DeleteModal() {
  const { tableLayout, tableLayoutDispatch } = useContext(TableContext);
  const currentData = tableLayout.data[tableLayout.modal.delete];
  const onSubmit = async () => {
    const res = await deleteData(tableLayout.url, currentData._id);
    console.log(res);
    tableLayoutDispatch({ type: "showDelete", payload: -1 });
  };
  return (
    <div className={styles.container}>
      <button
        onClick={() => tableLayoutDispatch({ type: "showDelete", payload: -1 })}
      >
        Close
      </button>
      <h2>If you want to delete this record ? Click Confirm.</h2>
      <button onClick={onSubmit}> Confirm </button>
    </div>
  );
}
