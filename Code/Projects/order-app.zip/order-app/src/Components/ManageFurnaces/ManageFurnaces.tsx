import TableLayout from "../TableLayout/TableLayout";

const ManageFurnaces = () => {
  return (
    <>
      <TableLayout columns={["name", "isOccupied"]} url={"furnace"} />
    </>
  );
};

export default ManageFurnaces;
