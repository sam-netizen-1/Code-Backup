import TableLayout from "../TableLayout/TableLayout";

const ManageCustomers = () => {
  return (
    <>
      <TableLayout
        columns={["name", "email", "shippingAddress", "state"]}
        url={"customer"}
      />
    </>
  );
};

export default ManageCustomers;
