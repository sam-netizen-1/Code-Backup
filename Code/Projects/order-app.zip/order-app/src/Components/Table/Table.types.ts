export interface ITableProps {
    mockData: {
        book: IBookProps[];
        totalPages: number;
        nextPage: boolean;
        prevPage: boolean;
    }
}

export type IBookProps = {
    id: number;
    name: string;
    author: string;
    price: number;
    dateOfPublication: number;
}