import { useContext } from "react";
// import Pagination from "../Pagination/Pagination";
import { TableContext } from "../TableLayout/TableLayout";
import style from "./Table.module.scss";

export default function Table() {
  const { tableLayout } = useContext(TableContext);

  return (
    <>
      <table className={style.table}>
        <thead>
          <tr>
            {tableLayout.columns.map((col: string) => (
              <th>{col.toUpperCase()}</th>
            ))}
            <th>ACTIONS</th>
          </tr>
        </thead>
        {tableLayout?.data.length && (
          <tbody>
            {tableLayout.data.map((row: any, index: number) => (
              <tr>
                {Object.entries(row)
                  .filter(([key]) => tableLayout.columns.includes(key))
                  .map(([key, value]: any) => (
                    <td>{value}</td>
                  ))}
                <td>{tableLayout.dataHandler(index)}</td>
              </tr>
            ))}
          </tbody>
        )}
      </table>
      {/* <Pagination data={mockData} /> */}
    </>
  );
}
