import React, { ChangeEvent, useState, useEffect } from "react";
import style from "./Pagination.module.scss";

export default function Pagination({ data }: any) {
  const [pageNumber, setPageNumber] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const handlePagination = (offset: number) => {
    setPageNumber(pageNumber + offset);
  };
  const handlePageSizeChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const { value } = e.target;
    setPageSize(parseInt(value));
  };
  const shouldPaginate = (condition: boolean, offset: number) => {
    if (condition) {
      handlePagination(offset);
    }
  };
  const getData = (pageNumber: any, pageSize: any) => data;
  useEffect(() => {
    getData(pageNumber, pageSize);
  }, [pageNumber, pageSize]);
  return (
    <div className={style.pagination}>
      <span onClick={() => shouldPaginate(data.prevPage, -1)}>&lt;</span>
      <span>{pageNumber + 1}</span>
      <span onClick={() => shouldPaginate(data.prevPage, 1)}>&gt;</span>
      <span>
        showing records: {pageNumber * pageSize + 1} to{" "}
        {pageNumber * pageSize + pageSize} / {data?.totalRecords}
      </span>
      <select onChange={handlePageSizeChange}>
        <option>10</option>
        <option>20</option>
        <option>50</option>
      </select>
    </div>
  );
}
