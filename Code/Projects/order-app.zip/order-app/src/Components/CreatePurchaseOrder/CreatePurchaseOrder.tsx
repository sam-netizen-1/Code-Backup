import { Field, FieldArray, Form, Formik } from "formik";
import { useEffect, useReducer } from "react";
import { useNavigate } from "react-router-dom";
import {
  getMaterial,
  getCustomer,
  getUnit,
  getHSN,
  postPurchaseOrder,
} from "../../Services/Methods/Clerk.Services";
import styles from "./CreatePurchaseOrder.module.scss";
import { dataReducer } from "./CreatePurchaseOrder.reducer";

const CreatePurchaseOrder = () => {
  const nav = useNavigate();
  const [data, setData] = useReducer(dataReducer, {});
  const getdata = async () => {
    const materials = await getMaterial();
    const customers = await getCustomer();
    const units = await getUnit();
    const hsn = await getHSN();
    setData({
      Materials: materials,
      Customers: customers,
      Units: units,
      HSN: hsn,
    });
  };
  useEffect(() => {
    getdata();
  }, []);

  return (
    <Formik
      initialValues={{
        customerIndex: "",
        customer: {
          name: "",
          email: "",
          shippingAddress: "",
          state: "",
        },
        products: [
          {
            productname: "",
            quantity: "",
            material: "",
            price: "",
            unit: "",
            hsn: "",
          },
        ],
      }}
      onSubmit={async (values: {
        customerIndex?: string;
        customer: {
          name: string;
          email: string;
          shippingAddress: string;
          state: string;
        };
        products: {
          productname: string;
          quantity: string;
          material: string;
          price: string;
          unit: string;
          hsn: string;
        }[];
      }) => {
        await postPurchaseOrder(values, data);
        nav("/");
      }}
    >
      {({ values }) => (
        <Form className={styles.purchaseOrder}>
          <Field
            className={styles.input}
            required
            name="customerIndex"
            as="select"
          >
            <option value="">Please Select a Customer.</option>
            {data.Customers?.map((customer: any, index: number) => (
              <option value={index}>{customer.name}</option>
            ))}
          </Field>
          {values.customerIndex !== "" &&
            (() => {
              values.customer.name = data.Customers[+values.customerIndex].name;
              values.customer.email =
                data.Customers[+values.customerIndex].email;
              values.customer.shippingAddress =
                data.Customers[+values.customerIndex].shippingAddress;
              values.customer.state =
                data.Customers[+values.customerIndex].state;
              return <></>;
            })()}
          <div className={styles.customerDetailsContainer}>
            <span className={styles.customerDetails}>
              {" "}
              Customer Name: {values.customer.name}{" "}
            </span>
            <span className={styles.customerDetails}>
              {" "}
              Customer Email: {values.customer.email}{" "}
            </span>
            <span className={styles.customerDetails}>
              Customer Shipping Address: {values.customer.shippingAddress}
            </span>
            <span className={styles.customerDetails}>
              {" "}
              Customer State: {values.customer.state}{" "}
            </span>
          </div>
          <FieldArray
            name="products"
            render={(arrayHelpers) => (
              <div className={styles.Container}>
                <div className={styles.AddItemsContainer}>
                  <button
                    className={styles.button}
                    type="button"
                    onClick={() =>
                      arrayHelpers.push({
                        productname: "",
                        quantity: "",
                        material: "",
                        price: "",
                        unit: "",
                        hsn: "",
                      })
                    }
                  >
                    Add Item
                  </button>
                </div>
                <div className={styles.ItemsContainer}>
                  {values.products.map((product, index) => (
                    <div className={styles.Items} key={index}>
                      <Field
                        className={styles.input}
                        required
                        placeholder="Enter Item Name"
                        name={`products[${index}].productname`}
                        type="text"
                      />
                      <Field
                        className={styles.input}
                        required
                        name={`products.${index}.quantity`}
                        type="number"
                        placeholder="Enter Item Quantity."
                      />
                      <Field
                        className={styles.input}
                        required
                        name={`products[${index}].material`}
                        as="select"
                      >
                        <option value="">Please Select a Material.</option>
                        {data.Materials?.map((material: any, index: number) => (
                          <option value={material.name}>{material.name}</option>
                        ))}
                      </Field>
                      <Field
                        className={styles.input}
                        required
                        name={`products.${index}.price`}
                        type="number"
                        placeholder="Enter Single Unit Price."
                      />
                      <Field
                        className={styles.input}
                        required
                        name={`products[${index}].unit`}
                        as="select"
                      >
                        <option value="">Please Select a Unit.</option>
                        {data.Units?.map((unit: any, index: number) => (
                          <option value={unit.name}>{unit.name}</option>
                        ))}
                      </Field>
                      <Field
                        className={styles.input}
                        required
                        name={`products.${index}.hsn`}
                        as="select"
                      >
                        <option value="">Please Select a HSN Code.</option>
                        {data.HSN?.map((customer: any, index: number) => (
                          <option value={index}>{customer.HSN_Code}</option>
                        ))}
                      </Field>
                      <button
                        className={styles.button}
                        type="button"
                        onClick={() => arrayHelpers.remove(index)}
                      >
                        Remove Item
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          />
          <button className={styles.button} type="submit">
            Submit
          </button>
        </Form>
      )}
    </Formik>
  );
};
export default CreatePurchaseOrder;
