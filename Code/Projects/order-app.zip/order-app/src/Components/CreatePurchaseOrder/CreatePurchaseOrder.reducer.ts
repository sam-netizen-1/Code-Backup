export const dataReducer = (state: any, action: any) => {
  return { ...state, ...action };
};
