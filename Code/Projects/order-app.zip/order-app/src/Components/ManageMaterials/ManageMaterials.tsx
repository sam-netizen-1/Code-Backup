import TableLayout from "../TableLayout/TableLayout";

const ManageMaterials = () => {
  return (
    <>
      <TableLayout columns={["name"]} url={"material"} />
    </>
  );
};

export default ManageMaterials;
