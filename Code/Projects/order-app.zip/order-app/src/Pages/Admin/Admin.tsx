import { Outlet } from "react-router-dom";
import SideBar from "../../Components/SideBar/SideBar";
import { sideBarStorage } from "../Main/Main.data";
import styles from "./Admin.module.scss";

const Admin = () => {
  const sidebar = sideBarStorage.Admin;
  return (
    <div className={styles.admin}>
      <SideBar sideBar={sidebar} />
      <Outlet />
    </div>
  );
};
export default Admin;
