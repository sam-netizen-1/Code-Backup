import { Outlet } from "react-router-dom";
import SideBar from "../../Components/SideBar/SideBar";
import { sideBarStorage } from "../Main/Main.data";
import styles from "./Accountant.module.scss";

const Accountant = () => {
  const sidebar = sideBarStorage.Accountant;
  return (
    <div className={styles.accountant}>
      <SideBar sideBar={sidebar} />
      <Outlet />
    </div>
  );
};
export default Accountant;
