import { useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import styles from "./Auth.module.scss";

const Auth = () => {
  const navigate = useNavigate();
  const [btnToggle, setBtnToggle] = useState(true);
  const navigateTo = (path: string) => {
    navigate(path);
    setBtnToggle(!btnToggle);
  };
  return (
    <section className={styles.login_container}>
      <Outlet />
      {btnToggle ? (
        <button
          className={styles.button}
          onClick={() => {
            navigateTo("forgetPassword");
          }}
        >
          Forget Password
        </button>
      ) : (
        <button
          className={styles.button}
          onClick={() => {
            navigateTo("/");
          }}
        >
          Login
        </button>
      )}
    </section>
  );
};
export default Auth;
