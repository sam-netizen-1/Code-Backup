export interface ILoginProps {
  clickFunction: (user: { userName: string; password: string }) => void;
}
