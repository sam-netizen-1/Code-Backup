import { createContext, useReducer, useState } from "react";
import { pageChanger } from "./Main.reducer";
import { routesProvider } from "./Main.routes";

export const MainContext = createContext<any>({});

const Main = () => {
  const [page, pageDispatch] = useReducer(pageChanger, {
    navigate: "Auth",
  });
  const [userId, setUserId] = useState();
  return (
    <MainContext.Provider
      value={{
        pageDispatch: pageDispatch,
        userId: userId,
        setUserId: setUserId,
      }}
    >
      {routesProvider(page.navigate)}
    </MainContext.Provider>
  );
};
export default Main;
