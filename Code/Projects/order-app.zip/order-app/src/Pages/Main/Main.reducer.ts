export const pageChanger = (state: any, action: any): any => {
  let navigate;
  if (action.type === "change") {
    navigate = action.payload;
  }
  return { ...state, navigate: navigate };
};
