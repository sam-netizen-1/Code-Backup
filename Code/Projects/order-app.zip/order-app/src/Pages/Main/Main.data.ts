export const sideBarStorage: any = {
  Admin: [
    { name: "Home", path: "/" },
    { name: "Approve Orders", path: "approve-orders" },
    { name: "Manage Customers", path: "manage-customers" },
    { name: "Manage Users", path: "manage-users" },
    { name: "Manage HSN", path: "manage-hsn" },
    { name: "Manage Materials", path: "manage-materials" },
    { name: "Manage Units", path: "manage-units" },
    { name: "Manage Storages", path: "manage-storage" },
    { name: "Manage Furnaces", path: "manage-furnaces" },
    { name: "Reports", path: "reports" },
    { name: "Profile", path: "user-profile" },
  ],
  Clerk: [
    { name: "Home", path: "/" },
    { name: "Create Purchase Order", path: "create-order" },
    { name: "Manage Orders", path: "manage-orders" },
    { name: "Profile", path: "user-profile" },
  ],
  Accountant: [
    { name: "Home", path: "/" },
    { name: "Manage Payments", path: "manage-payments" },
    { name: "Payment History", path: "payment-history" },
    { name: "Profile", path: "user-profile" },
  ],
};
