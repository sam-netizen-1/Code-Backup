import { Routes, Route } from "react-router-dom";
import ApproveOrder from "../../Components/ApproveOrder/ApproveOrder";
import ClerkHome from "../../Components/ClerkHome/ClerkHome";
import AdminHome from "../../Components/ClerkHome/ClerkHome";
import CreatePurchaseOrder from "../../Components/CreatePurchaseOrder/CreatePurchaseOrder";
import ForgetPassword from "../../Components/ForgetPassword/ForgetPassword";
import LoginBox from "../../Components/LoginBox/LoginBox";
import ManageCustomers from "../../Components/ManageCustomers/ManageCustomers";
import ManageFurnaces from "../../Components/ManageFurnaces/ManageFurnaces";
import ManageHSN from "../../Components/ManageHSN/ManageHSN";
import ManageMaterials from "../../Components/ManageMaterials/ManageMaterials";
import ManageStorages from "../../Components/ManageStorages/ManageStorages";
import ManageUnits from "../../Components/ManageUnits/ManageUnits";
import ManageUsers from "../../Components/ManageUsers/ManageUsers";
import ProfilePage from "../../Components/ProfilePage/ProfilePage";
import Accountant from "../Accountant/Accountant";
import Admin from "../Admin/Admin";
import Auth from "../Auth/Auth";
import Clerk from "../Clerk/Clerk";

const navigation: any = {
  Auth: {
    defaultPage: <Auth />,
    subComponents: [
      { index: "index", element: <LoginBox /> },
      { path: "forgetPassword", element: <ForgetPassword /> },
    ],
  },
  Admin: {
    defaultPage: <Admin />,
    subComponents: [
      { path: "/", index: true, element: <AdminHome /> },
      { path: "approve-orders", element: <ApproveOrder /> },
      { path: "user-profile", element: <ProfilePage /> },
      { path: "manage-users", element: <ManageUsers /> },
      { path: "manage-customers", element: <ManageCustomers /> },
      { path: "manage-storage", element: <ManageStorages /> },
      { path: "manage-furnaces", element: <ManageFurnaces /> },
      { path: "manage-hsn", element: <ManageHSN /> },
      { path: "manage-materials", element: <ManageMaterials /> },
      { path: "manage-units", element: <ManageUnits /> },
    ],
  },
  Clerk: {
    defaultPage: <Clerk />,
    subComponents: [
      { path: "/", index: true, element: <ClerkHome /> },
      { path: "create-order", element: <CreatePurchaseOrder /> },
      { path: "user-profile", element: <ProfilePage /> },
    ],
  },
  Accountant: {
    defaultPage: <Accountant />,
    subComponents: [
      // { path: "/", index: true, element: <AccountantHome /> },
      { path: "user-profile", element: <ProfilePage /> },
    ],
  },
};

export const routesProvider = (page: string) => {
  const currentPage = navigation[page];

  return (
    <Routes>
      <Route path={"/"} element={currentPage.defaultPage}>
        {currentPage.subComponents.map((data: any) => (
          <Route key={data.path} {...data}></Route>
        ))}
      </Route>
    </Routes>
  );
};
