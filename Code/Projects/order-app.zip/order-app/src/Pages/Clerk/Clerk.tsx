import { Outlet } from "react-router-dom";
import SideBar from "../../Components/SideBar/SideBar";
import { sideBarStorage } from "../Main/Main.data";
import styles from "./Clerk.module.scss";
const Clerk = () => {
  const sidebar = sideBarStorage.Clerk;
  return (
    <div className={styles.clerk}>
      <SideBar sideBar={sidebar} />
      <Outlet />
    </div>
  );
};
export default Clerk;
