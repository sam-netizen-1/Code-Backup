import http from "../Http/Http.Module";

export const login = async (user: { email: string; password: string }) => {
  const res = await http.post("auth/login", user);
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};

export const forgotPassword = async (user: { email: string }) => {
  const res = await http.post("auth/forgot-password", user);
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};
export const changePassword = async (
  userId: string,
  data: {
    oldPassword: string;
    newPassword: string;
    confirmNewPassword: string;
  }
) => {
  const res = await http.post(`auth/change-password/${userId}`, data);
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};

export const logout = async () => {
  const res = await http.get("auth/logout");
  http.emptyToken();
  return res;
};
