import http from "../Http/Http.Module";

export const logout = async () => {
  const res = await http.get("auth/logout");
  http.emptyToken();
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};
