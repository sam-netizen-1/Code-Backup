import http from "../Http/Http.Module";

export const getMaterial = async () => {
  const res = await http.get("material");
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};

export const getCustomer = async () => {
  const res = await http.get("customer");
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};

export const getHSN = async () => {
  const res = await http.get("HSN");
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};

export const getUnit = async () => {
  const res = await http.get("unit");
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};

export const postPurchaseOrder = async (
  data: {
    customer: {
      name: string;
      email: string;
      shippingAddress: string;
      state: string;
    };
    products: {
      productname: string;
      quantity: string;
      material: string;
      price: string;
      unit: string;
      hsn: string;
    }[];
  },
  allData: any
) => {
  const orderData: any = { products: [], customer: {} };
  orderData.customer = data.customer;
  data.products.forEach((product) => {
    const hsn = allData.HSN[product.hsn];
    const newObj = {
      productname: product.productname,
      quantity: +product.quantity,
      material: { name: product.material },
      price: +product.price,
      unit: { name: product.unit },
      hsn: { ...hsn },
    };
    orderData.products.push(newObj);
  });
  console.log(orderData);
  const res = await http.post("order/create-offer", orderData);
  console.log(res);
};
