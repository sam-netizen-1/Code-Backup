import http from "../Http/Http.Module";

export const getAllOrders = async () => {
  const res = await http.get("order");
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};
export const getData = async (url: string) => {
  const res = await http.get(url);
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};
export const addData = async (data: any, url: any) => {
  const res = await http.post(url, data);
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};
export const editData = async (data: any, url: any, id: any) => {
  const res = await http.put(`${url + "/" + id}`, data);
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};
export const deleteData = async (url: any, id: any) => {
  const res = await http.delete(`${url + "/" + id}`);
  if (res.data) {
    return res.data;
  } else {
    return { mesage: res.message };
  }
};
export const getPendingOrdersData = async () => {
  const res = await http.get("pending-orders");
  if (res.data) {
    return res.data;
  }
};
