import reference from "./reference.js";
import http from "./http.js";
import loginFunction from "./login.js";
import toggleDisplay from "./toggle.js";
import showRatingForm from "./rating.js";

const getRestaurantList = async () => {
  const res = await http.get("restaurants/");
  if (Array.isArray(res.data)) {
    return res.data;
  } else {
    return [];
  }
};

const displayRestaurantList = async () => {
  const list = await getRestaurantList();
  const temp = [];
  list.forEach((element) => {
    temp.push(
      `<button class="restaurant-names" id=${element.name
        .split(" ")
        .join("-")}>${element.id}. ${element.name} <span class="small">- ${
        element.address
      }</span></button>`
    );
  });
  let resturant = reference.restaurantNameContainer;
  resturant.innerHTML = ` <section class="restaurant-names-list"> ${temp.join(
    ""
  )} </section> `;
  await getButtons();
};

async function getButtons() {
  let reviewButtons = document.getElementsByClassName("restaurant-names");
  for (let btn of reviewButtons) {
    btn.addEventListener("click", () => {
      showRatingForm(`${btn.id}`);
      changeButtonState();
      btn.disabled = true;
    });
  }
}
const changeButtonState = () => {
  let reviewButtons = document.getElementsByClassName("restaurant-names");
  for (let btn of reviewButtons) {
    btn.disabled = false;
  }
};
displayRestaurantList();
reference.loginButton.addEventListener("click", () => {
  toggleDisplay(reference.loginContainer);
});
reference.closeButton.addEventListener("click", () => {
  toggleDisplay(reference.loginContainer);
});
reference.loginCnfrmButton.addEventListener("click", loginFunction);
