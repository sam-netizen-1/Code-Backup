import http from "./http.js";
import prompt from "./prompt.js";
const showAdminModal = async () => {
  let adminData = await http.get("user/reviews/");
  showAdminData(adminData.data);
};
const showAdminData = (adminData) => {
  const temp1 = [];
  const temp2 = [];
  const temp3 = [];
  adminData.restaurantAverage.forEach((element, index) => {
    temp3.push(element.reviews);
    temp2.push(element.average);
    temp1.push(
      `<button class="resto-names" id=${index}>${element.id}. ${element.name} <span class="small">- ${element.address}</span></button>`
    );
  });
  const body = document.body;
  const modalDiv = document.createElement("div");
  body.append(modalDiv);
  let arc = (adminData.OverallAverage / 5) * 100;
  modalDiv.innerHTML = `<div class='admin-modal-container'><button class="logout-admin" id="logout-admin">Logout</button><h1 class="admin-header">Admin</h1>
  <div class="admin-data"><div class="resto-list">${temp1.join(
    ""
  )}</div><div class="resto-average-card-container center-card" id="resto-average-card-container"></div><div class="overall-average-container"><h2>Overall Average</h2><div class="overall-average" style="--val:${arc}%" ><h3>${
    adminData.OverallAverage
  }</h3></div></div></div></div>`;

  const logoutButton = document.getElementById("logout-admin");
  logoutButton.addEventListener("click", () => {
    logout();
    modalDiv.remove();
  });

  let buttonList = document.getElementsByClassName("resto-names");
  let container = document.getElementById("resto-average-card-container");
  for (let btn of buttonList) {
    btn.addEventListener("click", (e) => {
      let arc = (temp2[+e.target.id] / 5) * 100;
      let temp = `<div class="overall-average-container"><h2>Restaurant Average</h2><div class="overall-average" style="--val:${arc}%" ><h3>${
        temp2[+e.target.id]
      }</h3></div></div>`;
      let tmp2 = `<ul class="reviews-lists-list">${temp3[+e.target.id].map(
        (element) => {
          return `<ul class="review-list">
      <li>Food :  ${element.Food} Stars</li>
      <li>Ambience :  ${element.Ambience} Stars</li>
      <li>Service :  ${element.Service} Stars</li>
      <li>Cleanliness :  ${element.Cleanliness} Stars</li>
      <li>Overall :  ${element.Overall} Stars</li>
      </ul>`;
        }
      )}</ul>`;
      container.innerHTML = temp + tmp2;
      changeButtonState();
      btn.disabled = true;
    });
  }
};
const logout = async () => {
  const res = await http.get("auth/");
  prompt(res.data.message);
};
const changeButtonState = () => {
  let buttons = document.getElementsByClassName("resto-names");
  for (let btn of buttons) {
    btn.disabled = false;
  }
};
export default showAdminModal;
