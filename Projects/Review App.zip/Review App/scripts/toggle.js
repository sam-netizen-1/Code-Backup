const toggleDisplay = (element) => {
  if (element.style.display === "flex") {
    element.style.display = "none";
  } else {
    element.style.display = "flex";
  }
};
export default toggleDisplay;
