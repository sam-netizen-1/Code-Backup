import http from "./http.js";
import prompt from "./prompt.js";
let rating = {
  Food: 3,
  Ambience: 3,
  Service: 3,
  Cleanliness: 3,
  Overall: 3,
};
let selectedResto;
const showRatingForm = (id) => {
  selectedResto = id.split("-").join(" ");
  const form = `
  <div class="container-1">
    <h2 class="form-heading">Rate The Restaurant</h2>
    <p class="resto-name" > Restaurant Name : ${selectedResto} </p>
  </div>
  <div class="container-2">
    <div class="inner-container-1">
      <p class="parameter" >Reviewer's Name : </p>
      <p class="parameter" > Food : </p>
      <p class="parameter" > Ambience : </p>
      <p class="parameter" > Service :  </p>
      <p class="parameter" > Cleanliness : </p>
      <p class="parameter" > Overall :  </p>
    </div>

    <div class="inner-container-2">
      <input name="user-name" placeholder="Enter Your Name" class="input-rating user-input" id="user-name" type="text" required >
      <input name="Food" class="input-rating inputRating" type="range" min="0" max="5" required >
      <input name="Ambience" class="input-rating inputRating" type="range" min="0" max="5" required > 
      <input name="Service" class="input-rating inputRating" type="range" min="0" max="5" required >
      <input name="Cleanliness" class="input-rating inputRating" type="range" min="0" max="5" required >
      <input name="Overall" class="input-rating inputRating" type="range" min="0" max="5" required > 
    </div>
    <div class="inner-container-3" id="inner-container-3">
      <p class="current-rating" > ${rating.Food} </p>
      <p class="current-rating" > ${rating.Ambience} </p>
      <p class="current-rating" > ${rating.Service} </p>
      <p class="current-rating" > ${rating.Cleanliness} </p>
      <p class="current-rating" > ${rating.Overall} </p>
    </div>
  </div>
  <div class="container-3">
    <button class="review-submit" id="review-submit" >Submit This Rating</button>
  </div>`;
  const ratingContainer = document.getElementById("rating-container");
  ratingContainer.innerHTML = form;

  const submitReviewBtn = document.getElementById("review-submit");
  submitReviewBtn.addEventListener("click", () => {
    postReviewData();
    ratingContainer.innerHTML = "";
    changeButtonState();
  });
  sliderFunction();
};

const postReviewData = async () => {
  rating.nameOfRestaurant = selectedResto;
  const userName = document.getElementById("user-name");
  rating.name = userName.value;
  let res = await http.post("restaurants/", rating);
  if (res.data) {
    prompt(res.data.message);
  }
};
const changeButtonState = () => {
  let reviewButtons = document.getElementsByClassName("restaurant-names");
  for (let btn of reviewButtons) {
    btn.disabled = false;
  }
};
const sliderFunction = () => {
  const sliders = document.getElementsByClassName("inputRating");
  for (let a of sliders) {
    a.addEventListener("change", (e) => {
      rating[e.target.name] = parseInt(e.target.value);
      const temp = `<p class="current-rating" > ${rating.Food} </p>
      <p class="current-rating" > ${rating.Ambience} </p>
      <p class="current-rating" > ${rating.Service} </p>
      <p class="current-rating" > ${rating.Cleanliness} </p>
      <p class="current-rating" > ${rating.Overall} </p>`;
      const container = document.getElementById("inner-container-3");
      container.innerHTML = temp;
    });
  }
};

export default showRatingForm;
