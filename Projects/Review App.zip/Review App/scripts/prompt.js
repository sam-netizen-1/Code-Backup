const prompt = (element) => {
  const body = document.body;
  const promptDiv = document.createElement("div");
  body.append(promptDiv);
  promptDiv.innerHTML = `<h3 class="prompt">${element}</h3>`;
  setTimeout(() => {
    promptDiv.remove();
  }, 3000);
};
export default prompt;
