const restaurantNameContainer = document.getElementById(
  "restaurant-name-container"
);
const ratingContainer = document.getElementById("rating-container");
const initialMessage = document.getElementById("initial-message");
const loginButton = document.getElementById("login");
const closeButton = document.getElementById("close-button");
const loginContainer = document.getElementById("login-container");
const loginCnfrmButton = document.getElementById("login-cnfrm");
export default {
  restaurantNameContainer,
  ratingContainer,
  initialMessage,
  loginButton,
  loginContainer,
  closeButton,
  loginCnfrmButton,
};
