import toggleDisplay from "./toggle.js";
import http from "./http.js";
import prompt from "./prompt.js";
import showAdminModal from "./admin.js";
import showManagerModal from "./manager.js";
const userName = document.getElementById("username");
const password = document.getElementById("password");

const loginFunction = async () => {
  let user = {};
  user.username = userName.value;
  user.password = password.value;
  const res = await http.post("auth/", user);
  if (res.data) {
    prompt(res.data.message);
    userName.value = "";
    password.value = "";
    toggleDisplay(document.getElementById("login-container"));
    if (res.data.role === "admin") {
      showAdminModal();
    } else if (res.data.role === "manager") {
      showManagerModal();
    }
  } else {
    prompt(res.error.message);
  }
};
export default loginFunction;
