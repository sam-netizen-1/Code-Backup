class HTTP {
  mainUrl = "http://192.168.11.95:3000/";
  userToken;
  async send(url, options = {}) {
    try {
      const response = await fetch(`${this.mainUrl}${url}`, options);
      const data = await response.json();
      if (data.data.token) {
        this.userToken = data.data.token;
      }
      return data;
    } catch (errorMsg) {
      return { title: "error", message: errorMsg };
    }
  }

  get(url) {
    if (url === "restaurants/") {
      return this.send(url);
    } else {
      return this.send(url, {
        method: "GET",
        headers: {
          authorization: this.userToken,
        },
      });
    }
  }

  post(url, data) {
    if (url === "restaurants/" || url === "auth/") {
      return this.send(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
    } else {
      return this.send(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          authorization: this.userToken,
        },
        body: JSON.stringify(data),
      });
    }
  }
}

const http = new HTTP();
export default http;
