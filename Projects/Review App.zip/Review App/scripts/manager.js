import http from "./http.js";
import prompt from "./prompt.js";
const showManagerModal = async () => {
  let managerData = await http.get("user/reviews");
  showManagerDashboard(managerData.data);
};
const showManagerDashboard = (managerData) => {
  const temp1 = [];
  const temp2 = [];
  const temp3 = [];
  managerData.forEach((element, index) => {
    const { name, average, ...ratings } = element;
    temp3.push(ratings);
    temp2.push(average);
    temp1.push(`<button class="reviewer-names" id=${index}>${name}</button>`);
  });
  const body = document.body;
  const modalDiv = document.createElement("div");
  body.append(modalDiv);
  modalDiv.innerHTML = `
    <div class="manager-modal-container">
    <button class="logout-manager" id="logout-manager" >Logout</button>
    <h2>Manager<h2>
    <div class="data-container">
    <div class="reviewer-names-container" id="reviewer-names-container">${temp1.join(
      ""
    )}</div>
    <div class="user-rating-container" id="user-rating-container"></div>
    <div class="average-rating-container" id="average-rating-container" ></div>
    </div>
    </div>
  `;

  const logoutButton = document.getElementById("logout-manager");
  logoutButton.addEventListener("click", () => {
    logout();
    modalDiv.remove();
  });

  let buttonList = document.getElementsByClassName("reviewer-names");
  let ratingContainer = document.getElementById("user-rating-container");
  let averageContainer = document.getElementById("average-rating-container");
  console.log(averageContainer);
  for (let btn of buttonList) {
    btn.addEventListener("click", (e) => {
      let arc = (temp2[+e.target.id] / 5) * 100;
      let tmp1 = `<div class="overall-average-container"><h2>Restaurant Average</h2><div class="overall-average" style="--val:${arc}%" ><h3>${
        temp2[+e.target.id]
      }</h3></div></div>`;
      let tmp2 = `<ul class="review-list">
      <li>Food :  ${temp3[+e.target.id].Food} Stars</li>
      <li>Ambience :  ${temp3[+e.target.id].Ambience} Stars</li>
      <li>Service :  ${temp3[+e.target.id].Service} Stars</li>
      <li>Cleanliness :  ${temp3[+e.target.id].Cleanliness} Stars</li>
      <li>Overall :  ${temp3[+e.target.id].Overall} Stars</li>
      </ul>`;

      averageContainer.innerHTML = tmp1;
      ratingContainer.innerHTML = tmp2;
      changeButtonState();
      btn.disabled = true;
    });
  }
};
const logout = async () => {
  const res = await http.get("auth/");
  prompt(res.data.message);
};
const changeButtonState = () => {
  let buttons = document.getElementsByClassName("reviewer-names");
  for (let btn of buttons) {
    btn.disabled = false;
  }
};
export default showManagerModal;
